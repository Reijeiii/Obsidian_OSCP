## **Ports and Services**

## **Notes**
```sh
#IPs
Client1: 10.0.2.10
Client2: 10.0.2.11
DC01: 10.0.2.9
```


Nwilliams
	no bloodhound data
	admin on client2
	


## **Loot**
```sh
#Initial Creds

#SMB access
bthompson : Iceman#8777

#Client1 admin
jmiller : Iceman#8777 

dpark : Martell_10

SVC_CONFIG : Kaylee@16
```

## **Checklists**