check bloodhound results. We have Outbound Object Control over JMILLER
![[Pasted image 20260818070438.png]]


We also have Kerberoastable user SVC_WEB
![[Pasted image 20260818070423.png]]