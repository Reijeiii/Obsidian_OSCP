Admins
![[Pasted image 20260813124954.png]]

Kerberoastable users
![[Pasted image 20260813125019.png]]