## **Ports and Services**

## **Notes**

``` sh
#IPs
Client1: 192.168.101.114
```

## **Loot**

``` sh
#Initial creds on Client1
emiller : raymond1:P

svc_web : oDr@gon13
```

## **Checklists**