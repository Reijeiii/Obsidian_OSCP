## **Ports and Services**

## **Notes**

``` sh
#IPs
DC01: 10.0.2.4
Client2: 10.0.2.9
Client1: 10.0.2.7
```

## **Loot**

``` sh
#inital creds
egreen : !!pLaYa!!90 (rdp client2 - did not work thou)
clee : !!XzUfrog69 (client2 rdp)
mross : !!TWIZtid11 (Client1 pwned)
zmiller : !!WaR1972!!
```


## **Checklists**