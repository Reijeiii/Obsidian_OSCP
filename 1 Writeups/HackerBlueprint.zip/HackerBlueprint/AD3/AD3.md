## **Ports and Services**

## **Notes**

## **Loot**

``` sh
#Initial creds
lfoster : Pindrop#1
adiaz : Peru123.
jbailey : Paulio*3

#Local user Client1 rdp
Brian : Iloveyou:D
```


not sure why red?
``` sh
Password123!!    (HACK-ACADEMY.LOCAL/Administrator) 
```
## **Checklists**