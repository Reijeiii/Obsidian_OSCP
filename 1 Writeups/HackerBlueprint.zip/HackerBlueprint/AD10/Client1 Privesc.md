![[Pasted image 20260818122001.png]]

```sh
ServiceName    : AppLogService
Path           : C:\Program Files\AppLogService\applog.exe
ModifiablePath : @{ModifiablePath=C:\; IdentityReference=NT AUTHORITY\Authenticated Users; Permissions=AppendData/AddSubdirectory}
StartName      : LocalSystem
AbuseFunction  : Write-ServiceBinary -Name 'AppLogService' -Path <HijackPath>
CanRestart     : False
Name           : AppLogService
Check          : Unquoted Service Paths

ServiceName    : AppLogService
Path           : C:\Program Files\AppLogService\applog.exe
ModifiablePath : @{ModifiablePath=C:\; IdentityReference=NT AUTHORITY\Authenticated Users; Permissions=System.Object[]}
StartName      : LocalSystem
AbuseFunction  : Write-ServiceBinary -Name 'AppLogService' -Path <HijackPath>
CanRestart     : False
Name           : AppLogService
Check          : Unquoted Service Paths
```