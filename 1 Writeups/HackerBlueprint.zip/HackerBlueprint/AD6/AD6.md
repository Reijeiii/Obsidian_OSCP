## **Ports and Services**

## **Notes**

``` sh
#IPs
Client1: 10.0.2.7
Client2: 10.0.2.9
DC01: 10.0.2.4
```
## **Loot**

``` sh
#initial creds
sortiz : Shade3729a.
websvc : Shade3729a. 
vlang : Shar4334!
folsen : Phish28*
```

## **Checklists**