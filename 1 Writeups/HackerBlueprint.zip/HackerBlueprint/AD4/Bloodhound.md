## Admins
![[Pasted image 20260813092451.png]]

AS-REP Roast
![[Pasted image 20260813092513.png]]