## **Ports and Services**

## **Notes**

``` sh
#IPs
Client1: 192.168.101.113
```

## **Loot**

``` sh
#initial Creds on Client1
lcarter : Awesome!

#Client2
csander : *Gillian*

rcooper : Password@123
```

## **Checklists**