
## **Ports and Services**

## **Notes**

``` sh
Client1: 10.0.2.26
Client2: 10.0.2.27
DC01: 10.0.2.100

```

## **Loot**
``` sh
#Initial creds
eturner : Ya-Boy14
svc_webapi : Andrew,3
svc_monitor : Memorex|
svc_reports : (Evista-
kpatel : 100%Mary
svc_admin : -Berlin-
```

## **Checklists**