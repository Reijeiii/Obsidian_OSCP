Admins
![[Pasted image 20260817074455.png]]

Kerberoastable users
![[Pasted image 20260817074519.png]]