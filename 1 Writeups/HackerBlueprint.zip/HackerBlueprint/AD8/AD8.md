## **Ports and Services**

## **Notes**
```sh
#IPs
Client1: 10.0.2.11
DC01: 10.0.2.9
Client2: 10.0.2.10

```
## **Loot**
``` sh
jgarcia : Welcome2025!
svc_archive : Softball1!
mharris : Finance2024!
twright : Solo2007!
svc_deploy : 140190-KS
```

## **Checklists**