## **Ports and Services**

## **Notes**
``` sh
Client1: 10.0.2.7 
Client2: 10.0.2.9
DC: 10.0.2.4

hack-academy.local
```
## **Loot**

``` sh
#Initial creds for client1
lbennett:!!reiD123

twest:HappyCactus$10 (winrm on client1)
matt:Password1! (RDP Client1)
eknight:!!Stud87 (winrm Client2 PWNED!)
mthomson:Password123!!
```

## **Checklists**

